<title>Authoritative Product Rules</title>

# 00 — Autoritative produktregler (V1-oprydning)

**Status:** Låst. Denne fil er den ENESTE kilde til produktretningen for
V1-oprydningen. Kilde: `FleetControl_V1_product_blueprint.md` (vedlagt af
ejeren/Dennis, dateret 24.08.2026), krydsrefereret mod
`docs/product-audit/` (den faktuelle kodeaudit, samme dag).

⚠ **Denne runde er kun planlægning og verifikation. 0 ændringer i
produktkode, Firebase-regler, Cloud Functions eller data er foretaget for
at producere dette dokumentsæt.**

## Målet

En første salgsbar og brugbar V1 til mindre og mellemstore
transport-/servicevirksomheder. Ikke en omskrivning — en oprydning. De
stærkeste tekniske flows (booking/etape-motoren, Warehouse, Unitbooking,
chaufførappens offline-kø) bevares uændret. Det der strammes er
informationsarkitekturen, navigationen, dashboardet og de parallelle
indgange, samt at ufærdige flader stopper med at udgive sig for færdige.

## Produktgrundlov (10 regler, ordret fra blueprintet)

1. Hver skærm har ét primært formål og én tydelig hovedhandling.
2. Hver forretningshandling har ét kanonisk hjem; andre steder må kun være
   genveje eller filtrerede views.
3. Moduler ejer deres faglige objekter: Planning=transport, Fleet=enheder/
   drift, Facility=bygning/anlæg, Procure=indkøb, Warehouse=kundegods,
   Unitbooking=udlejningsenheder, Workforce=personale.
4. Fælles objekter er platformfunktioner: kunder, leverandører,
   fakturaer/bilag, brugere, reservationer, audit og notifikationer.
5. Opsætning er administration, ikke daglig drift.
6. Et produktions-UI viser enten ægte data, en ærlig tomtilstand eller
   ingenting — aldrig permanente demo-rækker forklædt som kundedata.
7. Navigation følger brugerens arbejde og købte moduler; serverpermissions
   er fortsat den egentlige sikkerhed.
8. Dashboardet viser undtagelser, beslutninger og næste handling — ikke
   alle tilgængelige KPI'er.
9. Kun én primær blå handling pr. arbejdsområde; grøn/gul/rød bruges kun
   til status og risiko.
10. Ufærdige funktioner skjules eller markeres tydeligt som beta; de
    præsenteres ikke som færdige gennem deaktiverede attrapknapper.

**Regel 7 kræver et præcist skel, som resten af dokumentsættet
respekterer:** navigationssynlighed (hvad der TEGNES i menuen — en
kommerciel/UX-beslutning) er en ANDEN mekanisme end permissions (hvad
serveren FAKTISK tillader — sikkerhedskontrollen). Det er samme skel som
`kraeverModul`/`kraeverPerm` i dagens `nav.js` allerede håndhæver for et
mindretal af skærme — V1-oprydningen udvider princippet, den opfinder det
ikke.

## Ny hovednavigation (målbillede — se 02_TARGET_NAVIGATION.md for detaljer)

**Fælles:** Dashboard · Kunder (kun når relevant) · Fakturaer & bilag ·
Økonomi / Fakturagrundlag
**Driftsmoduler efter abonnement:** Planning · Fleet · Facility · Procure ·
Warehouse · Unitbooking · Workforce
**Administration:** Opsætning
**Hjælp:** Enkel hjælp/kontakt i V1; fuldt supportsagssystem senere

## Dashboard-reglen

- Én aktivt købt modul: ingen Samlet-vælger; brugeren lander direkte på
  modul-dashboardet.
- To eller flere moduler: vælgeren viser Samlet + de moduler brugeren må
  se.
- Samlet dashboard viser 3–6 handlingskort og én prioriteret
  arbejdslistesektion — ikke alle modul-KPI'er.
- Brugerens ekstra widgets ligger i en sekundær, sammenklappelig sektion;
  der indføres ikke et vilkårligt dataloft.

## Beslutningsfordeling (62 skærme)

| Beslutning | Antal | Betyder |
|---|---:|---|
| KEEP | 21 | Uændret placering og formål, mindre finish/verifikation |
| FINISH | 18 | Beholdes, men et reelt hul lukkes før V1 |
| MERGE | 8 | Funktionen bevares, men ophører som selvstændig menu-skærm |
| MOVE | 8 | Skærmen består, men flytter menuplacering |
| HIDE | 3 | Fjernes fra V1-navigationen, kode bevares |
| LATER | 4 | Skjules til datakilden/mekanismen er reel, kode bevares |

Se `01_ROUTE_DISPOSITION.md` for alle 62 rækker med change-type-tags.

## De to verificerede konflikter — nu FAKTA, ikke længere åbne

Blueprintets §"To konflikter der skal verificeres før kodeændringer" er
hermed lukket. Verificeret direkte mod kørende kode og DEV-miljøet
`fleetcontrol-dev-1ac1c` d. 24.08.2026, som en del af denne planlægningsrunde
(ingen mutation):

### A. Fleet/Facility `sager`-backend — FINDES OG ER DEPLOYET

- **Kildekode:** `functions/index.js` definerer `sagOpret` (linje 5300),
  `sagBeskedSkriv` (5381), `sagKarantaeneFrigiv` (5451), `sagAftaleBekraeft`
  (5498) — alle fire som `onCall`-funktioner.
- **Regler:** `firebase.rules.json` har en fuldt specificeret `sager`-node
  (under `tenants/<t>/sager`) med `.write: false` for alle klienter (kun
  de fire Cloud Functions kan skrive), `.read` gated på permission
  `sag.laes`, og fuld feltvalidering (nummer-format `FLT|FAC-ÅÅÅÅ-NNNNN`,
  `art` ∈ {fleet, facility}, `tilstand` ∈ {aaben, afventerSvar, afsluttet},
  polymorf `objektType`/`objektId`-reference, `parter`-adgangsliste,
  `securityLevel`).
- **Deployment:** `firebase functions:list --project dev` bekræfter alle
  fire funktioner som `v2 callable` i `europe-west1`, aktivt deployeret.
- **Konklusion:** Backend er REEL, ikke kun dokumenteret. Det tidlige
  auditmateriale (dossier 04/05, Fleet/Facility) tog fejl ved kun at læse
  en forældet frontend-kommentar ("fase 0") uden selv at slå
  `firebase.rules.json`/`functions/index.js` op — den senere syntese
  (dossier 10/`04_DATA_OWNERSHIP.md`) havde ret. **Hullet ligger
  udelukkende i frontend:** `Sagsvisning.jsx` har stadig alle handlinger
  deaktiveret og viser en forældet "fase 0"-tekst, selvom backend kan
  bruges i dag.
- **Betydning for V1-planen:** Fleets og Facilitys kanoniske arbejdsgange
  ("kommunikation" med leverandør/værksted) kan lukkes ved at koble
  `Sagsvisning.jsx` til det eksisterende, virkende backend-lag — dette er
  et `VIEW_COMPOSITION`+`BACKEND_REQUIRED`-hybridarbejde i det forstand at
  backend'en allerede findes, men *modtagevejen* (indgående mail →
  `sagOpret`, skive 2 i beslutning 20/112's egen plan) mangler stadig og
  ER et reelt `BACKEND_REQUIRED`-hul. Se detaljer i
  `03_CANONICAL_WORKFLOWS.md` og `05_IMPLEMENTATION_SLICES.md` (Skive 3).

### B. `kompetencer` — ER MODUL-GATET TIL BEMANDING I PRAKSIS

- **`NODE_MODUL` (src/fleet/moduler.js):** koden sætter eksplicit
  `kompetencer: "bemanding"`.
- **Deployede regler (firebase.rules.json, linje 863-872):** `.read`
  kræver `moduler/bemanding === true`; `.write` kræver derudover
  `kompetencer.skriv`-permission. Begge er reelt håndhævet i DEV.
- **Modsigelsen:** `moduler.js`'s egen forklarende kommentar (nær
  `NODE_MODUL`'s hoved) hævder "personale, kompetencer og kpi er heller
  ikke gatede" — denne sætning er FORÆLDET/forkert. Koden og de deployede
  regler er autoriteten, ikke kommentaren.
- **Konklusion:** `kompetencer` er en almindelig, korrekt modul-gatet Fleet
  … nej, Bemanding-node, præcis som `fravaer` og `stemplinger`. Der er intet
  sikkerhedshul og intet akut behov for en kodeændring her — kun en
  fremtidig oprydning af den vildledende kommentar i `moduler.js` (uden for
  scope for V1-navigationsoprydningen, nævnes for fuldstændighedens skyld i
  `04_DATA_AND_PERMISSION_IMPACT.md`).
- **Betydning for V1-planen:** Blueprintets "Workforce > Kompetencer
  (FINISH)"-beslutning kræver INGEN permission-modelændring for selve
  visningen — den er allerede korrekt spærret. Det der mangler, er en
  kanonisk SKRIVE-vej for kompetence-/bevisvedligehold (i dag kun læsning
  + en deaktiveret "Overrul"-knap, jf. `06_IMPLEMENTATION_STATUS.md`) — det
  er et `BACKEND_REQUIRED`+`VIEW_COMPOSITION`-arbejde, ikke et
  `PERMISSION_MODEL`-arbejde.

## Definition of Done for hele oprydningsprogrammet

(Ordret fra blueprintet, gengivet her som den overordnede accept-test hele
skive-planen til sidst skal bestå — se `06_TEST_AND_ROLLBACK_PLAN.md` for
hvordan hver enkelt skive verificeres undervejs.)

- En bruger ser kun købte moduler og relevante arbejdsområder.
- Ingen produktionssynlig komponent viser permanente demo-rækker som
  kundedata.
- Samme handling har ét kanonisk hjem; dubletter er redirects, filtre
  eller kontekstpaneler.
- Alle V1-flows kan gennemføres end-to-end uden deaktiverede kerneknapper.
- Hver skærm følger én af fem sidetyper: modul-forside, kalender,
  arbejdskø, proces eller stamdata.
- Alle 7 roller og relevante modulkombinationer er valideret i DEV.
- Fuld test-suite er grøn, og der findes en dokumenteret rollback pr.
  skive.

## Hvad denne plan IKKE gør

- Foreslår ingen funktion ud over blueprintet.
- Ændrer ingen kode, Firebase-regler, Cloud Functions eller data.
- Begynder ikke på Skive 1 uden en ny, eksplicit besked fra ejeren.
- Erstatter ikke `docs/product-audit/` — det dokumentsæt forbliver den
  faktuelle "hvad findes i dag"-kilde; `docs/product-redesign-v1/` er "hvad
  skal der ske"-planen bygget ovenpå det.
