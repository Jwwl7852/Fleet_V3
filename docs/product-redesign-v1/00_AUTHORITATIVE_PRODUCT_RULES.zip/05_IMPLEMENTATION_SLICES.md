<title>05 — Implementeringsskiver</title>

# 05 — Implementeringsskiver

**Status:** Planlægning. 0 kodeændringer er foretaget for at producere dette
dokument. Kilder: `FleetControl_V1_product_blueprint.md`,
`docs/product-redesign-v1/00_AUTHORITATIVE_PRODUCT_RULES.md`,
`docs/product-audit/02_SCREEN_INVENTORY.md`,
`docs/product-audit/06_IMPLEMENTATION_STATUS.md`,
`docs/product-audit/10_DUPLICATION_AND_OVERLAP_REPORT.md`,
`docs/product-audit/04_DATA_OWNERSHIP.md`, samt direkte læsning af
`src/App.jsx`, `src/fleet/nav.js` og `src/fleet/AppShell.jsx`.

Hvor kilderne ikke giver et entydigt svar (typisk om en skrivevej findes for
en node der i dag kun har læsning), er det markeret **IKKE PÅVIST** fremfor
gættet — i overensstemmelse med reglen der gælder resten af
`docs/product-redesign-v1/`.

De 7 change-type-tags bruges konsekvent:
`NAVIGATION_ONLY` · `VIEW_COMPOSITION` · `ROUTE_REDIRECT` ·
`PERMISSION_MODEL` · `DATA_MODEL` · `BACKEND_REQUIRED` · `HIDE_ONLY`.

---

## Skive 0 — Lås produktplanen

**✅ Afsluttet af denne planlægningsrunde.**

- `docs/product-redesign-v1/` er oprettet, med `00_AUTHORITATIVE_PRODUCT_RULES.md`
  som den låste kilde til produktretningen, krydsrefereret mod
  `FleetControl_V1_product_blueprint.md` og `docs/product-audit/`.
- De to konflikter blueprintet krævede verificeret, er nu FAKTA (se
  `00_AUTHORITATIVE_PRODUCT_RULES.md`, afsnit "De to verificerede
  konflikter"):
  - **A.** Fleet/Facility `sager`-backend (`sagOpret`, `sagBeskedSkriv`,
    `sagKarantaeneFrigiv`, `sagAftaleBekraeft`) er **reelt bygget og
    deployeret** (`functions/index.js`, `firebase.rules.json` linje
    863–872-området, bekræftet `v2 callable` i DEV) — hullet er udelukkende i
    `Sagsvisning.jsx`, som stadig viser en forældet "fase 0"-tekst.
  - **B.** `kompetencer` er **korrekt modul-gatet** til Bemanding
    (`NODE_MODUL.kompetencer = "bemanding"`, håndhævet i
    `firebase.rules.json`) — ingen permission-ændring krævet, kun en
    fremtidig oprydning af en vildledende kodekommentar i `moduler.js`
    (uden for scope for V1-navigationsoprydningen).
- Ingen kode, Firebase-regler, Cloud Functions eller data er ændret.

Skive 0 kræver ingen yderligere handling. De følgende otte skiver kan
igangsættes én ad gangen efter eksplicit godkendelse fra ejeren, som
blueprintets eget "Første besked til programmørrobotten" kræver.

---

## Skive 1 — Fjern vildledning

### Formål
Skjul permanente demo-/fase-0-flader fra produktionsnavigationen og erstat
de sidste permanente demo-komponenter på **skærme der bliver stående** med
ærlige tomtilstande, så produktgrundlovens §6 ("aldrig permanente
demo-rækker forklædt som kundedata") holder også for direkte URL-adgang.

### Berørte rækker (blueprint-#)
- **#2** Økonomi & Rapporter (`/oekonomi`) — LATER.
- **#11** Bemandingsplan (`/bemanding`) — LATER.
- **#21** Klima & energi (`/facility/klima`) — LATER.
- **#51** Integrationer (`/opsaetning/integrationer`) — LATER.
- **#52/#53/#54** Hjælp & Support / Supportoverblik / Supportsag
  (`/support`, `/support/overblik`, `/support/sag/:id`) — HIDE.
- **Permanente demo-komponenter på skærme der IKKE skjules** — den reelle
  liste, jf. `06_IMPLEMENTATION_STATUS.md`s "Integrationer der kun er UI" og
  det tilhørende MOCK-afsnit:
  - **Dashboard** (`/`, #1 FINISH, forbliver eneste indgang): tabellen "Åbne
    opgaver der kræver opfølgning" importerer `DEMO_DASHBOARD_OPGAVER`
    direkte og ubetinget — ikke via `useListe`s fallback-mekanisme. Dette er
    den ENESTE post i 06-dokumentet der eksplicit er mærket "permanent, ikke
    kun offline-fallback" for Dashboard.
  - **Kunder** (`/opsaetning/kunder`, #46 FINISH, forbliver i navigationen):
    kortet "Tilbud der kræver opfølgning" læser `DEMO_TILBUD` ubetinget; der
    findes ingen `tilbud`-node i datamodellen. Dossier 09/10 fremhæver denne
    som den ENESTE komponent i sit scope der viser demo-data også i en
    produktions-forbundet tilstand.
  - **Økonomi** (`demo-oekonomi.js`s kategori-nedbrydning +
    `DEMO_KLAR_TIL_FAKTURERING`) og **Bemanding** (`DEMO_BEMANDINGSPLAN`) er
    IKKE med på denne liste — begge skærme (`/oekonomi`, `/bemanding`) hører
    selv til LATER-gruppen ovenfor og skjules fra nav i denne skive. Koden
    bevares uændret ("Bevar koden som senere rapporthub" / "Genintroducér
    først med ægte plan"), og det er derfor billigere at skjule end at
    rette indholdet nu.
  - **Legitim offline-fallback, RØRES IKKE:** langt de fleste andre
    `demo:`-brug i kodebasen er `useListe(node, { demo: DEMO_X })` — kun
    aktiv når der ingen Firebase-forbindelse er (demoMode). Det er den
    tilsigtede mekanisme (jf. CLAUDE.md's "Vise et demo-datasæt for en node
    der ER seedet") og skal IKKE ændres i denne skive.

### Præcise filer og routes
**`src/fleet/nav.js`** — brug det eksisterende `skjulINav: true`-mønster
(allerede brugt på `forslag`- og `arbejdskoe`-børnene) på:
- `oekonomiOversigt`-barnet (sti `/oekonomi`) i `oekonomi`-gruppen.
  ⚠ Gruppens EGET `sti`-felt (linje ~239, `key: "oekonomi", sti: "/oekonomi"`)
  skal samtidig ændres til `/oekonomi/fakturacenter` — ellers klikker
  brugeren stadig ind på den skjulte rapportside via selve gruppens
  `NavLink`, fordi `Fakturacenter` og `Fakturering` forbliver synlige børn og
  gruppen derfor IKKE forsvinder fra sidebaren (se `AppShell.jsx` linje 149:
  et toppunkt tegnes, hvis mindst ét barn er synligt).
- `bemandingPlan`-barnet (sti `/bemanding`) i `bemanding`-gruppen.
  ⚠ Samme mekanik: gruppens eget `sti` (linje ~41) skal ændres til
  `/bemanding/kompetencer`, fordi `kompetencer` og `fravaer` forbliver
  synlige og gruppen ("Workforce") derfor stadig vises.
- `klima`-barnet (sti `/facility/klima`) i `facility`-gruppen. Intet
  repoint nødvendigt — `facility`-gruppens eget `sti` (`/facility`) peger på
  Overblik-siden, som IKKE skjules.
- `integrationer`-barnet (sti `/opsaetning/integrationer`) i
  `opsaetning`-gruppen. Intet repoint nødvendigt (gruppens `sti` er
  `/opsaetning`, Generelt-siden, KEEP).
- Alle tre børn i `support`-gruppen (`hjaelp`, `supportOverblik`,
  `supportSag`). Med alle tre skjult forsvinder HELE "Support"-toppunktet
  automatisk fra sidebaren (samme `AppShell.jsx`-mekanik: et toppunkt uden
  synlige børn tegnes ikke — bekræftet i kildekoden, linje 149).

**Route-laget i `src/App.jsx`** rører IKKE — alle seks ruter
(`/oekonomi`, `/bemanding`, `/facility/klima`, `/opsaetning/integrationer`,
`/support`, `/support/overblik`, `/support/sag/:id`) forbliver deklareret
uændret. Dette er ikke en forglemmelse: CLAUDE.md forbyder eksplicit at
`App.jsx` filtrerer ruter på `kraeverPerm`/nav-synlighed ("et dybt link skal
ende i en forklaring, ikke i en 404"), og `test/rutedeling.test.mjs` +
mønsteret i `test/navadgang.test.mjs` forudsætter at ruten stadig findes.

**Komponentfiler der får en ærlig tomtilstand-guard** (nyt, minimalt —
genbruger det eksisterende `dataTilstand()`/`<Datatilstand>`-mønster fra
`fleet/datatilstand.js`/`fleet/ui.jsx`, opfinder intet nyt):
- `src/moduler/Oekonomi.jsx` (`/oekonomi`)
- `src/moduler/Bemanding.jsx` (`/bemanding`)
- `src/moduler/facility/Klima.jsx` (`/facility/klima`)
- `src/moduler/opsaetning/Integrationer.jsx` (`/opsaetning/integrationer`)
  — laveste prioritet: skærmen er allerede bevidst tom (ingen `demo:`-brug),
  kræver reelt kun nav-skjul.
- `src/moduler/support/Hjaelp.jsx`, `src/moduler/support/Overblik.jsx`,
  `src/moduler/support/Sag.jsx` (alle tre `/support*`)

  Begrundelse: uden guarden viser disse syv skærme fortsat
  `DEMO_BEMANDINGSPLAN` (`src/fleet/demo-bemanding.js`), Økonomis
  kategori-nedbrydning/`DEMO_KLAR_TIL_FAKTURERING` (`src/fleet/demo-oekonomi.js`)
  og `DEMO_SUPPORTSAGER`/`DEMO_TENANTS` (`src/fleet/demo-support.js`) for
  enhver bruger der taster URL'en direkte — hvilket er nøjagtigt den
  tilstand produktgrundlovens §6 forbyder, blot uden et menupunkt der fører
  derhen.

**Komponentfiler der får deres permanente demo-komponent fjernet/erstattet**
(disse skærme forbliver i nav og skal derfor være ærlige, ikke kun skjulte):
- `src/moduler/Dashboard.jsx` — fjern det ubetingede
  `DEMO_DASHBOARD_OPGAVER`-import (`src/fleet/demo-dashboard.js`) fra
  "Åbne opgaver der kræver opfølgning"-tabellen; erstat med en ærlig
  tomtilstand indtil en rigtig kilde findes (ingen ny aggregering bygges i
  denne skive — det er et separat, ubesluttet spørgsmål).
- `src/moduler/Kunder.jsx` — fjern det ubetingede `DEMO_TILBUD`-import
  (`src/fleet/demo-kunder.js`) fra "Tilbud der kræver opfølgning"-kortet;
  erstat med en ærlig tomtilstand eller fjern kortet helt, da ingen
  `tilbud`-node findes i datamodellen.

### Change-type tag(s) pr. berørt element
- `nav.js`-ændringerne (skjulINav + `sti`-repoint): **NAVIGATION_ONLY**
- Tomtilstand-guard på de syv skjulte routes: **VIEW_COMPOSITION**
- Dashboard.jsx / Kunder.jsx demo-fjernelse: **VIEW_COMPOSITION**
- Ingen `PERMISSION_MODEL`, `DATA_MODEL` eller `BACKEND_REQUIRED`-arbejde i
  denne skive.

### Migrationsbehov
Ingen. Ingen node, regel eller Cloud Function ændres. Ren frontend-
synlighed og -indhold.

### Risici
- **Den vigtigste risiko er præcis den `AppShell.jsx` allerede
  dokumenterer:** en skjult route findes stadig, og det er bevidst (regel 7:
  "Navigation følger... serverpermissions er fortsat den egentlige
  sikkerhed"). Risikoen er IKKE at ruten er nåbar — det er korrekt — men at
  den, hvis nået, viser demo-data som var det ægte kundedata. Det er derfor
  denne skive inkluderer tomtilstand-guards, ikke kun nav-skjul.
- Repoint af `oekonomi`- og `bemanding`-gruppernes eget `sti`-felt er let at
  overse, fordi det ikke er nævnt eksplicit i blueprintet — overses det,
  forbliver den skjulte rapport-/demoside reelt ét klik væk via
  gruppeoverskriften, og HIDE/LATER-beslutningen er reelt ikke effektueret.
- At fjerne `DEMO_DASHBOARD_OPGAVER`/`DEMO_TILBUD` uden erstatning efterlader
  et tomt kort på to skærme brugere ser dagligt — skal ledsages af en kort,
  forklarende tomtilstandstekst, ikke bare et hul.
- Enhver ny reference til `demo-bemanding.js`/`demo-oekonomi.js`/
  `demo-support.js` fra en KEPT/FINISH-skærm ville underminere arbejdet i
  denne skive — ingen sådan reference er fundet i det læste materiale, men
  bør bekræftes ved implementering (`grep` for filnavnene på tværs af
  `src/moduler/`).

### Testcases
- `test/demo-i-skaerm.test.mjs` — tæller `demo:`-brug for noder der ER
  seedet; skal forblive grøn (ingen af ændringerne rører seedede noders
  `useListe`-fallback-mønster).
- `test/demo-kilder.test.mjs` — fejler på to demo-sæt for samme node eller
  et demo-sæt defineret i en modulfil frem for `fleet/demo-*.js`; relevant
  fordi Dashboard/Kunder-guardene ikke må efterlade en lokal kopi af
  `DEMO_DASHBOARD_OPGAVER`/`DEMO_TILBUD` i selve skærmfilen.
- `test/demo-referencer.test.mjs` — hvis tomtilstand-guarden ved et uheld
  refererer et id fra et demosæt der ikke findes i den seedede base.
- `test/navadgang.test.mjs` — kræver en skreven grund for hvert
  `kraeverPerm`-punkt; nye `skjulINav`-flag ændrer ikke selve
  permission-kravene, men testen bør køres for at bekræfte at ingen
  utilsigtet permission-kobling er brudt.
- `test/rutedeling.test.mjs` — bekræfter at hver lazy-loaded rute stadig har
  et `export default`; kritisk efter enhver redigering af de syv
  komponentfiler.
- `test/datatilstand.test.mjs` — hvis den findes og dækker
  `<Datatilstand>`-mønsteret; bekræfter at guarden bruger den etablerede
  komponent og ikke en ny, lokal fejltekst (forbudt af CLAUDE.md: "skriv ikke
  din egen fejltekst i en skærm").

### Definition of Done
- [ ] `/oekonomi`, `/bemanding`, `/facility/klima`,
      `/opsaetning/integrationer`, `/support`, `/support/overblik`,
      `/support/sag/:id` er væk fra sidebaren for enhver rolle/modulkombination.
- [ ] "Økonomi & Rapporter"-gruppens og "Workforce"-gruppens `NavLink` peger
      på hhv. Fakturacenter og Kompetencer, ikke på de skjulte sider.
- [ ] "Support"-toppunktet er helt væk fra sidebaren (ikke kun dets tre børn).
- [ ] De syv skjulte routes viser en ærlig, kort forklarende tomtilstand ved
      direkte URL-besøg — ikke `DEMO_BEMANDINGSPLAN`/`DEMO_SUPPORTSAGER`/etc.
- [ ] Dashboard viser ikke længere `DEMO_DASHBOARD_OPGAVER` under nogen
      omstændighed; Kunder viser ikke længere `DEMO_TILBUD`.
- [ ] `npm test` er grøn, inkl. de fem testfiler nævnt ovenfor.
- [ ] Ingen ændring i `firebase.rules.json` eller `functions/`.

### Rollback-plan
Ren UI-synligheds- og -indholdsændring uden datamigration. Rollback =
`git revert` af skivens commit(s). Ingen node, regel eller Cloud Function er
rørt, så der er intet at rulle tilbage på databasesiden. De skjulte routes'
kode forbliver i repoet under hele skiven (blueprintets eget krav: "kode
bevares"), så en revert er triviel og risikofri.

---

## Skive 2 — Navigation og dashboard

### Formål
Indføre en rolle+modul-baseret navigationssynlighed adskilt fra
permissions (produktgrundlov §7), bygge modulvælgeren og
dashboard-standardlayoutet blueprintet kræver: én-modul-kunder lander
direkte på deres modul-dashboard, fler-modul-kunder kan vælge Samlet.

### Berørte rækker (blueprint-#)
- **#1** Dashboard (`/`) — FINISH: modulvælger kun ved 2+ aktive moduler,
  maksimér handlingskøen.
- Ny hovednavigation (blueprintets afsnit "Ny hovednavigation"): Fælles
  (Dashboard, Kunder når relevant, Fakturaer & bilag, Økonomi/
  Fakturagrundlag), Driftsmoduler efter abonnement, Administration
  (Opsætning), Hjælp.
- Dashboard-reglen (blueprintets afsnit "Dashboard-regel"): 1 modul → intet
  Samlet-valg; 2+ moduler → vælger med Samlet + tilladte moduler; Samlet
  viser 3–6 handlingskort + én arbejdsliste; brugerens ekstra widgets i
  sammenklappelig sekundær sektion, intet vilkårligt dataloft.

### Præcise filer og routes
- `src/fleet/nav.js` — omdøb/omgruppér topniveauet til at matche den nye
  hovednavigation: `oekonomi`-gruppen opsplittes konceptuelt (Fakturacenter
  bliver reelt fælles i Skive 4, men NAVIGATIONS-strukturen — gruppenavn
  "Fakturaer & bilag" for Fakturacenter, "Økonomi / Fakturagrundlag" for
  Fakturering — kan forberedes her). `kunder`-punktet ("Kunder & Priser",
  i dag kun nået via Opsætning, jf. `02_SCREEN_INVENTORY.md` §9.1) flyttes
  til et rigtigt topniveaupunkt under "Fælles", betinget af `kraeverModul:
  "kunder"` som i dag.
- `src/fleet/AppShell.jsx` — udvid `synligeBorn`/topniveau-filtreringen
  (linje 108–149) med en ny lagdeling: rolle+modul-baseret nav-synlighed
  **ud over** de eksisterende `kraeverModul`/`kraeverPerm`. Dette er den
  "separate navigation/dashboard-synlighed pr. bruger" blueprintets række
  **#50** (Brugere & roller) selv nævner som en tilføjelse, ikke en
  erstatning af serverpermissions.
- `src/moduler/Dashboard.jsx` — implementér dashboard-reglens
  betinget-visning: brug `moduler`-konteksten (allerede tilgængelig via
  `useFleet()`) til at afgøre 1-modul vs. 2+-modul-landing, og byg den
  sammenklappelige "ekstra widgets"-sektion oven på det eksisterende
  `brugerlayout/<uid>/<dashboard>`-lag (allerede BUILT, jf.
  `06_IMPLEMENTATION_STATUS.md` §01).
- `src/fleet/dashboards.js`/`src/fleet/widgets.js` — det eksisterende
  widget-katalog (CLAUDE.md: "der stod tolv widgets... i BÅDE `widgets.js`
  og regelfilen") er allerede den korrekte mekanisme for brugerens eget
  layout; "3–6 handlingskort"-reglen for Samlet-dashboardet er en ny,
  separat grænse der skal defineres ved siden af, IKKE ved at sætte et loft
  på `valideLayout()` (som CLAUDE.md eksplicit forbyder at bruge som
  adgangskontrol).

### Change-type tag(s) pr. berørt element
- Nav-omgruppering/omdøbning: **NAVIGATION_ONLY**
- Rolle+modul nav-synlighedslag i `AppShell.jsx`: **PERMISSION_MODEL**
  (bemærk: dette er en UI-synlighedsmodel oven på eksisterende server-
  permissions, IKKE en ændring af `firebase.rules.json` — jf. 00's
  præcisering af §7-skellet)
- Dashboard modulvælger + Samlet-landing-logik: **VIEW_COMPOSITION**
- Ingen `DATA_MODEL`- eller `BACKEND_REQUIRED`-arbejde i denne skive.

### Migrationsbehov
Ingen datamigration. Hvis "navigation/dashboard-synlighed pr. bruger"
(række #50) kræver et nyt felt (fx `dashboardvisning`-lignende node pr.
bruger for NAV-synlighed, adskilt fra den eksisterende
`dashboardvisning`-node for widget-synlighed), er dette en ny, additiv
RTDB-sti — IKKE PÅVIST om en sådan allerede findes for nav (kun for
dashboard-widgets, jf. `test/dashboardvisning.test.mjs`). Skal verificeres
ved implementeringsstart, før feltet navngives.

### Risici
- At forveksle den nye NAV-synlighedsmodel med en adgangskontrol — CLAUDE.md
  er eksplicit: "Basere adgangskontrol på rollen, hvis det egentlig er en
  permission" er forbudt. Enhver ny nav-gating skal afspejle en reel
  server-permission eller et reelt modulkøb, aldrig omvendt.
  `test/navadgang.test.mjs`s princip ("et punkt må kun bære `kraeverPerm`
  hvis reglen faktisk kræver den") skal udvides til den nye lagdeling.
- Dashboard-reglens "3–6 handlingskort" er en UX-grænse uden datamæssig
  håndhævelse i dag — risiko for at den implementeres som et hårdt loft i
  `widgets.js`-kataloget, hvilket CLAUDE.md eksplicit advarer imod
  (beslutning 43/44: "en anbefaling... ikke en kendsgerning om systemet").
- Omdøbning af `oekonomi`-nav-gruppen før Skive 4's reelle omlægning af
  Fakturacenter til fælles platformfunktion kan skabe et navn/indhold-gab
  (gruppen hedder "Fakturaer & bilag", men Fakturacenter er stadig
  `kraeverPerm: "indkoeb.laes"`-gated som i dag) — bør sekvenseres bevidst,
  eller udskydes til Skive 4 hvis det er enklere at gøre navn og
  funktionalitet i samme commit.

### Testcases
- `test/navadgang.test.mjs`
- `test/kpiadgang.test.mjs`, `test/laeseadgang.test.mjs` — bekræfter at
  KPI-/læse-adgang forbliver udledt af serverpermissions, uanset
  nav-lagdelingen.
- `test/dashboards.test.mjs`, `test/dashboardvisning.test.mjs`,
  `test/widgets.test.mjs` — dashboard-layoutmekanikken.
- `test/moduler.test.mjs`, `test/modulopslag.test.mjs`,
  `test/modulmangler.test.mjs`, `test/modulkrav.test.mjs` — modulgating
  generelt, da den nye nav-lagdeling bygger oven på `harModul()`.
- `test/rules.rollematrix.test.mjs` — sikrer at ingen af de 7 roller mister
  en reel serveradgang som utilsigtet sideeffekt af nav-ændringen.

### Definition of Done
- [ ] En kunde med ét aktivt modul lander direkte på modul-dashboardet, uden
      Samlet-vælger.
- [ ] En kunde med 2+ moduler ser en vælger med Samlet + de moduler brugeren
      må se (ikke alle kundens moduler, hvis brugerens rolle er begrænset).
- [ ] Samlet-dashboardet viser 3–6 handlingskort og én prioriteret
      arbejdslistesektion.
- [ ] Brugerens ekstra widgets ligger sammenklappet, uden hårdt dataloft.
- [ ] Navigationen matcher blueprintets "Ny hovednavigation"-struktur
      (Fælles/Driftsmoduler/Administration/Hjælp).
- [ ] `npm test` grøn.

### Rollback-plan
Nav-omgruppering og dashboardlogik er ren frontend — `git revert`. Hvis et
nyt RTDB-felt for nav-synlighed pr. bruger blev tilføjet, er feltet additivt
(påvirker ingen eksisterende læsning), så en kode-revert efterlader et ubrugt,
men harmløst felt i basen — ingen sletning nødvendig for en ren rollback.

---

## Skive 3 — Planning/Fleet/Facility

### Formål
Fjerne det duplikerede værkstedsdagsgitter fra Disponering, integrere
Forslag som panel/dialog i Disponering, merge Fleets Arbejdskø ind i
Driftskalenderen, og lukke to reelle huller: Fleets indberetningstriage og
Sagsvisning.jsx's kobling til den nu bekræftede `sager`-backend.

### Berørte rækker (blueprint-#)
- **#7** Forslag & reservation (`/booking/forslag/:id`) — MERGE ind i
  Disponerings højre panel/dialog; route bevares som deep link
  (`skjulINav: true`, allerede sat i `nav.js`).
- **#8** Disponering (`/booking/disponering`) — FINISH: fjern
  dagsgitteret for værkstedsopgaver.
- **#17** Indberetninger (`/flaade/indberetninger`) — FINISH: byg triage
  (prioritet, vurdering, planlæg aktivitet, afvent, afslut, kobling til
  Fleet-sag). Markeret i blueprintet som "V1-blokerende hul".
- **#18** Arbejdskø (`/flaade/koe`) — MERGE ind i Driftskalenderens
  arbejdskø/drawer; route bevares som deep link (allerede `skjulINav: true`).
- **#22** Servicedialog — KEEP, standardisér knapper/leverandørkontakt/næste
  handling med Fleets dialog uden fælles feltskema.
- (Underliggende, ikke en selvstændig blueprint-række men eksplicit navngivet
  i `00_AUTHORITATIVE_PRODUCT_RULES.md`:) `Sagsvisning.jsx`-kobling til den
  bekræftede `sagOpret`/`sagBeskedSkriv`/`sagKarantaeneFrigiv`/
  `sagAftaleBekraeft`-backend, samt indgående mail → `sagOpret` (fortsat et
  reelt `BACKEND_REQUIRED`-hul, uafhængigt af at frontend-koblingen sker).

### Præcise filer og routes
- `src/moduler/booking/Disponering.jsx` — fjern dagsgitter-fanen for
  værkstedsopgaver (art `vaerksted`); denne opgavetype vises fremover kun i
  Fleets Driftskalender (`src/moduler/flaade/Vaerkstedskalender.jsx`, route
  `/flaade`). Ugesgitteret (etaper/langture) bevares uændret — det er
  bevidst view-only i dag og påvirkes ikke.
- `src/moduler/booking/Forslag.jsx` (route `/booking/forslag/:id`, allerede
  `skjulINav: true` i `nav.js`) — indholdet flyttes til et panel/dialog der
  åbnes FRA Disponering (`src/moduler/booking/Disponering.jsx`); selve
  komponentfilen kan forblive som deep-link-mål, eller dens JSX udtrækkes
  til en delt komponent begge steder importerer. Ingen ny node eller
  Cloud Function — `forslagskriv`/`etapeskift` er allerede BUILT
  (`06_IMPLEMENTATION_STATUS.md` §02).
- `src/moduler/flaade/Arbejdskoe.jsx` (route `/flaade/koe`, allerede
  `skjulINav: true`) — samme mønster: indhold/filterlogik
  (`driftstal()`-funktionen, allerede bevidst delt med Driftskalenderens
  fem kasser jf. `10_DUPLICATION_AND_OVERLAP_REPORT.md`) flyttes ind i
  `src/moduler/flaade/Vaerkstedskalender.jsx` som en arbejdskø/drawer,
  åbnet fra de fem eksisterende handlingstal.
- `src/moduler/flaade/Indberetninger.jsx` (route `/flaade/indberetninger`)
  — bygger den manglende triage: "Afslut"-knappen er i dag permanent
  deaktiveret ("Fase 0: skrives ikke fra klienten endnu",
  `06_IMPLEMENTATION_STATUS.md` §04). Kræver en NY Cloud Function (eller
  udvidelse af en eksisterende) til at skifte en indberetnings status og
  koble den til en Fleet-sag — ingen sådan funktion er fundet i
  `functions/index.js` i det læste materiale.
- `src/moduler/support/Sag.jsx` findes IKKE — den relevante komponent er
  `Sagsvisning.jsx` (Fleet/Facility-modulet, jf.
  `10_DUPLICATION_AND_OVERLAP_REPORT.md`s eksplicitte adskillelse fra
  Support-modulets `Sag.jsx`). ⚠ **Præcis fil-sti for `Sagsvisning.jsx` er
  IKKE PÅVIST i det materiale der er læst i denne runde** (den optræder i
  `docs/product-audit/`-dossiererne og i `00_AUTHORITATIVE_PRODUCT_RULES.md`
  under navnet, men uden fuld sti) — skal lokaliseres (`grep -r
  "Sagsvisning" src/`) som allerførste skridt i denne skive, før
  ændringsomfanget kan estimeres præcist. Arbejdet: erstat de deaktiverede
  "Send besked"/"Frigiv karantæne"-knapper med reelle kald til
  `sagBeskedSkriv`/`sagKarantaeneFrigiv`, fjern "fase 0"-teksten.
- Indgående mail → `sagOpret` — **ingen eksisterende fil**; dette er et nyt
  modtagelseslag (mail-parsing, sagsnummer-udtræk fra emnefeltet jf.
  CLAUDE.md's `sagsnummerFraEmne()`-note, karantæne/scanning) uden for
  scope for frontend-arbejdet ovenfor. Kræver egen delleverance
  (SMTP/webhook-modtager + Cloud Function), ikke kun en skærmændring.

### Change-type tag(s) pr. berørt element
- Disponerings dagsgitter-fjernelse: **VIEW_COMPOSITION**
- Forslag-merge ind i Disponering: **VIEW_COMPOSITION** (route bevares som
  `ROUTE_REDIRECT`-lignende deep link, men er teknisk set allerede
  `skjulINav` — ingen ny redirect-mekanik nødvendig)
- Arbejdskø-merge ind i Driftskalender: **VIEW_COMPOSITION**
- Fleet indberetningstriage: **BACKEND_REQUIRED** (ny/udvidet Cloud
  Function for statusskift + sagskobling)
- Sagsvisning.jsx-kobling til eksisterende `sager`-backend:
  **VIEW_COMPOSITION** + **BACKEND_REQUIRED**-hybrid, præcis som
  `00_AUTHORITATIVE_PRODUCT_RULES.md` selv klassificerer det: backend
  findes allerede for besked/frigivelse, men mail-modtagevejen er et
  selvstændigt, reelt `BACKEND_REQUIRED`-hul.

### Migrationsbehov
Ingen migration for gitter-/panel-mergene (samme node, samme Cloud
Functions, kun UI-omlægning). For indberetningstriage og
Sagsvisning-koblingen: ingen data-migration, men en NY Cloud Function skal
deployes og dens regler tilføjes til `firebase.rules.json` (kun for
indberetningstriage — `sager`-reglerne findes allerede for
Sagsvisning-koblingen, jf. Skive 0's verifikation).

### Risici
- Dagsgitter-fjernelse fra Disponering rører en komponent
  (`Gitterkalender.jsx`) der er **bevidst delt** med Driftskalender og
  Servicekalender (jf. `10_DUPLICATION_AND_OVERLAP_REPORT.md`, "Funktioner
  der måske burde være fælles platformfunktioner"). En ændring i den delte
  komponent for at fjerne KUN Disponerings værksteds-fane må ikke bryde de
  to andre kalenderes visning — CLAUDE.md's advarsel om "to gitre der
  læser samme interval forskelligt" gælder direkte her.
- Fleet indberetningstriage er markeret "V1-blokerende hul" af blueprintet
  selv — det er reelt ny backend-funktionalitet, ikke kun UI, og bør ikke
  undervurderes som en "aktivér en deaktiveret knap"-opgave.
- Sagsvisning.jsx's nøjagtige fil-sti er ikke bekræftet i denne
  planlægningsrunde — risiko for fejlestimering hvis filen viser sig at
  være større/mere sammenflettet med andre skærme end antaget.
- Mail-modtagevejen (`sagOpret` fra indgående mail) er en ekstern
  angrebsflade (karantæne/scanning nævnt eksplicit i CLAUDE.md: "Vise en
  karantæneret besked i tråden" er forbudt inline) — bør behandles som sin
  egen sikkerhedsgennemgang, ikke som en delopgave i en UI-skive.

### Testcases
- `test/gitter.test.mjs`, `test/gitter-uge.test.mjs` — den delte
  kalenderkomponents regnestykke.
- `test/disponering.test.mjs`, `test/forslag.test.mjs`,
  `test/forslagform.test.mjs` — Disponering/Forslag-flowet og det kendte
  `.forslag.length`-mønsterforbud (beslutning 76).
- `test/etapeskift.test.mjs`, `test/etapeskifte.test.mjs`,
  `test/opgaveflyt.test.mjs`, `test/opgaveplan.test.mjs`,
  `test/opgaver.test.mjs`, `test/opgavestatus.test.mjs` — de fire
  skriveveje ind i `opgaver` som gitter-omlægningen ikke må røre.
  `test/indeslutning.test.mjs` — "hallen og porten er ét rum"-tjekket.
- `test/facilityopgave.test.mjs`, `test/facility.test.mjs`,
  `test/facility-drift.test.mjs` — Facility-siden af den delte
  gitterkomponent, som IKKE må påvirkes af Disponerings dagsgitter-fjernelse.
- `test/flaade.test.mjs`, `test/flaade-bemanding.test.mjs`,
  `test/vaerksted.test.mjs`, `test/driftskalender.test.mjs` — Driftskalender
  efter Arbejdskø-mergen.
- `test/indberetninger.test.mjs`, `test/indberetningsarter.test.mjs`,
  `test/rules.indberetninger.test.mjs` — indberetningsmodellen den nye
  triage-funktion skal skrive imod.
- `test/sager.test.mjs`, `test/sager-funktioner.test.mjs` — den allerede
  deployerede `sager`-backend, Sagsvisning.jsx skal kobles til.
- `test/referencetjek.test.mjs` — hvis triage-funktionen introducerer et nyt
  `...Id`-referencefelt (fx en kobling fra indberetning til Fleet-sag).

### Definition of Done
- [ ] Disponering viser ikke længere et separat dagsgitter for
      værkstedsopgaver; Driftskalenderen er eneste sted at se/redigere dem.
- [ ] Forslag & reservation nås kun fra Disponerings panel/dialog i normal
      brug; `/booking/forslag/:id` virker stadig som deep link.
- [ ] Arbejdskø nås kun fra Driftskalenderens fem kasser; `/flaade/koe`
      virker stadig som deep link.
- [ ] Fleet Indberetninger har en fungerende "Afslut"-handling koblet til en
      Fleet-sag.
- [ ] Sagsvisning.jsx's "Send besked"/"Frigiv karantæne" virker mod den
      rigtige backend; "fase 0"-teksten er fjernet.
- [ ] `npm test` og `npm run test:rules` grønne (den sidste er obligatorisk
      hvis nye Cloud Function-regler tilføjes).

### Rollback-plan
Gitter-/panel-mergene: `git revert` — ingen datamigration. Den nye Cloud
Function til indberetningstriage kan deaktiveres ved at fjerne dens
klient-kald (frontend-revert) uden at slette selve funktionen fra
`functions/index.js` med det samme — en udrullet, ubrugt Cloud Function er
harmløs. Hvis `firebase.rules.json` er udvidet, kræver rollback en ny
`npm run test:rules` + `npm run regler:udrul` af den tilbagerullede
regelfil, IKKE kun en git-revert af filen (jf. CLAUDE.md: "prøverne siger
noget om FILEN; databasen håndhæver det UDRULLEDE").

---

## Skive 4 — Fakturaer, leverandører og Procure

### Formål
Gøre Fakturacenter til en fælles platformfunktion uafhængig af
Procure-abonnement, fjerne den parallelle Procure-fakturaskærm til fordel
for en redirect, gøre Leverandører til fælles stamdata med CRUD, og lukke
to reelle, uafhængige backend-huller: fillagring til Fakturacenter og
reel ordre-mail-afsendelse i Procure.

### Berørte rækker (blueprint-#)
- **#3** Fakturacenter (`/oekonomi/fakturacenter`) — FINISH: fælles
  platformfunktion, drag-and-drop/fillagring FØRST, invoice-mail/OCR kan
  følge som senere kanaler.
- **#27** Procure-fakturaer (`/indkoeb/fakturaer`) — MERGE: redirect til
  Fakturacenter med Procure-filter.
- **#28** Leverandører (`/indkoeb/leverandoerer`) — MOVE: fælles stamdata
  for Fleet, Facility og Procure; byg CRUD.
- **#25** Bestillinger (`/indkoeb/bestillinger`) — FINISH: reel
  mailafsendelse med PO-nummer.

### Præcise filer og routes
- `src/moduler/oekonomi/Fakturacenter.jsx` (route `/oekonomi/fakturacenter`)
  — match/godkendelse/bogføring er allerede BUILT (Cloud Functions
  `fakturadestination`/`fakturastatus`). Det manglende er
  **indgangskanalerne**: `06_IMPLEMENTATION_STATUS.md` §01 siger direkte
  "Ingen indgangskanal — kræver fillagring som ikke findes i platformen".
  Dette er en platform-bred mangel, ikke kun en skærmmangel: **ingen fil-
  lagring findes noget sted i FleetControl i dag** (bekræftet indirekte af
  gentagne "kræver fillagring"-noter for foto/kvittering i Procure Behov
  §6.2, chaufførindberetning §11.3, og Leverandørers prisliste-vedhæftning).
  At bygge drag-and-drop/fillagring til Fakturacenter er derfor reelt at
  bygge platformens FØRSTE fillagringslag — en arkitekturbeslutning
  (Firebase Storage vs. andet), ikke kun en UI-komponent.
- `src/moduler/indkoeb/Fakturaer.jsx` (route `/indkoeb/fakturaer`) — erstat
  skærmens indhold med en `ROUTE_REDIRECT` til
  `/oekonomi/fakturacenter?filter=procure` (eller tilsvarende
  querystring-filter). `src/fleet/nav.js`s `fakturaer`-barn i
  `indkoeb`-gruppen fjernes eller peges om. Ingen datamigration: begge
  skærme læser/skriver allerede samme `fakturaer/`-node
  (`10_DUPLICATION_AND_OVERLAP_REPORT.md` bekræfter "bevidst delt,
  u-gatet basenode").
- `src/moduler/indkoeb/Leverandoerer.jsx` (route `/indkoeb/leverandoerer`)
  — i dag "FASE 0: VISNING" (ingen skrivehandling,
  `06_IMPLEMENTATION_STATUS.md` §06). Skal have opret/redigér-CRUD.
  **Skrivevejen for `leverandoerer`-noden er IKKE PÅVIST** i det læste
  materiale (hverken bekræftet som `.write:false` med en dedikeret Cloud
  Function, eller som en almindelig `gem()`-skrivbar node) — skal
  afklares mod `firebase.rules.json` som allerførste skridt i skiven, da
  det afgør om arbejdet er ren `VIEW_COMPOSITION` (hvis noden allerede kan
  skrives direkte) eller kræver en ny Cloud Function.
  Menuplacering flyttes samtidig fra kun `/indkoeb/leverandoerer` til en
  fælles stamdatasti (fx under Opsætning, ved siden af Enheder/Medarbejdere/
  Kasseliste-mønsteret i `nav.js`s `opsaetning`-gruppe), med `kraeverModul`
  fjernet eller udvidet så Fleet/Facility-brugere uden Procure også kan nå
  den — **IKKE PÅVIST** hvorvidt dette kræver en ny `kraeverModul: "basis"`-
  værdi eller blot ingen `kraeverModul` (som Kunder-punktet).
- `src/moduler/indkoeb/Bestillinger.jsx` (route `/indkoeb/bestillinger`) —
  "Kopiér udkast"/"Markér som sendt" er i dag manuel
  (`06_IMPLEMENTATION_STATUS.md` §06: "Systemet sender ikke udkastene").
  Kræver en ny Cloud Function med reel SMTP/afsenderadresse-integration
  (ingen SMTP-kald findes i `functions/index.js` i det læste materiale).
- `src/fleet/nav.js` — flyt "Flyt godkendelsespolicy til Opsætning >
  Procure" (blueprint #26): `Godkendelser.jsx`s beløbsgrænse-/
  godkender-opsætning flyttes til Opsætning, siden viser fortsat den
  aktive regel (allerede delvist bygget, jf.
  `10_DUPLICATION_AND_OVERLAP_REPORT.md`: begge skærme læser samme
  `godkendelsesregler`-node).

### Change-type tag(s) pr. berørt element
- Fakturacenter fillagring/drag-and-drop: **BACKEND_REQUIRED** (platformens
  første fillagringslag — den tungeste enkeltopgave i denne skive)
- Procure-fakturaer → redirect: **ROUTE_REDIRECT**
- Leverandører CRUD: **VIEW_COMPOSITION** eller **BACKEND_REQUIRED**
  afhængig af IKKE PÅVIST-punktet ovenfor; **NAVIGATION_ONLY** for
  menuflytningen til fælles stamdata
- Reel ordre-mail: **BACKEND_REQUIRED**
- Godkendelsespolicy-flytning: **NAVIGATION_ONLY** + **VIEW_COMPOSITION**
  (opsætningsskærmen skal bygges, driftsskærmen skal vise reglen read-only)

### Migrationsbehov
- Fillagring: ny infrastruktur (Storage-bucket eller tilsvarende) — ingen
  eksisterende data at migrere, men en ny sikkerhedsmodel skal designes
  (hvem må uploade/læse hvilke filer, hvordan spærres på tenant — analogt
  til RTDB's `auth.token.tenant === $tenantId`-mønster).
- Leverandører-CRUD: ingen migration af selve `leverandoerer`-noden hvis
  skrivevejen allerede findes; hvis en ny Cloud Function bygges, ingen
  migration, kun en ny regel + funktion.
- Godkendelsespolicy-flytning: ingen migration, samme node.

### Risici
- Fillagring er den enkeltopgave i hele skiveplanen der har størst risiko
  for at blive undervurderet — det ser ud som "tilføj en upload-knap", men
  er reelt platformens første fillagringsarkitektur, med konsekvenser for
  GDPR/retention (CLAUDE.md's `RETENTION_MAANEDER`-mønster gælder formentlig
  også filer, ikke kun RTDB-poster — **IKKE PÅVIST** om retentionsmodellen
  i dag dækker andet end RTDB).
- Leverandører flyttet til fælles stamdata uden at afklare skrivevejen
  først kan resultere i enten en unødvendig ny Cloud Function (hvis
  `gem()` allerede virker) eller et forsøg på at skrive direkte til en
  `.write:false`-node (hvis den ikke gør) — begge fejlretninger er dyre at
  opdage sent.
- Procure-fakturaer-redirecten skal bevare eksisterende bogmærker/links
  (samme mønster som `REDIRECTS` i `nav.js` for tidligere flytninger) —
  overses dette, brydes eksterne links til siden.
- Reel mailafsendelse (både her og i indgående sagsmail, Skive 3) er en
  ekstern integration med driftsrisiko (afsenderdomæne, SPF/DKIM,
  leveringsfejl) der ikke er dækket af den eksisterende testsuite.

### Testcases
- `test/fakturacenter.test.mjs`, `test/faktura.test.mjs` — den delte
  `fakturaer/`-node og match/godkendelses-logikken.
- `test/leverandoerer.test.mjs`, `test/rules.leverandoerer.test.mjs` —
  leverandørnodens regler og eksisterende (læse-)adfærd.
- `test/indkoeb.test.mjs`, `test/rules.procure.test.mjs`,
  `test/procure.test.mjs`, `test/bestilling.test.mjs`,
  `test/behov.test.mjs`, `test/godkendelse.test.mjs` — hele
  Procure-kæden, som ikke må brydes af redirect/CRUD-ændringerne.
- `test/priser.test.mjs`, `test/pricing-forloeb.test.mjs` — hvis
  Leverandørers prislister rører prismotoren.
- Ny testfil forventet for fillagring (findes ikke i dag) —
  **IKKE PÅVIST**, men bør følge samme mønster som `test/rules.*`-filerne:
  udled tilladte stier af den nye Storage-sikkerhedsmodel, test dem i
  emulator.

### Definition of Done
- [ ] Fakturacenter tilgængeligt uden Procure-modul, som fælles
      platformfunktion.
- [ ] Mindst én reel indgangskanal (drag-and-drop-upload) virker end-to-end
      mod en rigtig fillagring.
- [ ] `/indkoeb/fakturaer` redirecter til Fakturacenter med Procure-filter;
      ingen selvstændig fakturaskærm i Procure-menuen.
- [ ] Leverandører har opret/redigér-CRUD og er nået som fælles stamdata,
      ikke kun fra Procure-menuen.
- [ ] Bestillinger sender en reel mail til leverandøren med PO-nummer.
- [ ] Godkendelsespolicy er flyttet til Opsætning > Procure; driftsskærmen
      viser fortsat den aktive regel.
- [ ] `npm test` og `npm run test:rules` grønne.

### Rollback-plan
Redirect og CRUD-UI: `git revert`, ingen datatab (samme node som før).
Fillagring: hvis en Storage-bucket er oprettet, kan koden der uploader
dertil rulles tilbage uden at slette bucketen — uploadede filer forbliver,
men bliver utilgængelige fra UI'et igen (accepteret midlertidig tilstand,
ikke datatab). Mail-afsendelse: deaktiver Cloud Function-kaldet i klienten
(revert), lad selve funktionen ligge udrullet men ubrugt.

---

## Skive 5 — Unitbooking og Warehouse

### Formål
Merge Unitbookings Kalender/Udlån til én arbejdsflade, samle reolpladser/
lokationer i én fælles stamdataskærm, skabe en ny Warehouse-forside, flytte
Bevægelser til et avanceret undermenupunkt, og gøre transportlabels
kontekstuelle.

### Berørte rækker (blueprint-#)
- **#30** Kalender (`/unitbooking`) — FINISH: samlet arbejdsflade.
- **#31** Udlån (`/unitbooking/udlaan`) — MERGE ind i Kalender.
- **#33** Reolpladser (`/unitbooking/reolpladser`) og **#45** Lokationer
  (`/warehouse/lokationer`) — MERGE til én fælles skærm under
  Opsætning > Lagerlokationer.
- **#35** Varer (`/warehouse`) — MOVE: ny Warehouse-forside, varekartotek
  flyttes til underside.
- **#37** Bevægelser (`/warehouse/bevaegelser`) — MOVE til Warehouse >
  Mere > Bevægelser.
- **#41** Transportlabels (`/warehouse/labels`) — MERGE: kontekstuel fra
  Beholdere/Modtagelse.

### Præcise filer og routes
- **#33/#45-mergen er allerede næsten gratis, bekræftet mod
  `04_DATA_OWNERSHIP.md`:** `reolpladser` er "den ENESTE node i kodebasen
  med eksplicit deling mellem to navngivne moduler
  (`NODE_MODUL.reolpladser = ["unitbooking", "warehouse"]`)", og begge
  skærme (`src/moduler/unitbooking/Reolpladser.jsx`,
  `src/moduler/warehouse/Lokationer.jsx`) skriver allerede med `flet:true`
  til den SAMME node, netop for at undgå at overskrive hinandens felter.
  Arbejdet er derfor reel UI-konsolidering (én skærm, modulbestemte felter
  vist betinget), ikke en datamodel-ændring — ingen ny node, ingen ny
  Cloud Function, ingen migration. Placeres under Opsætning som fælles
  stamdatasti, `kraeverModul` sættes til at acceptere ENTEN
  `"unitbooking"` ELLER `"warehouse"` (**IKKE PÅVIST** om `kraeverModul`
  i dag understøtter en array/OR-værdi som `nav.js`-feltet — kun
  `NODE_MODUL` i reglerne gør det per `04_DATA_OWNERSHIP.md`; skal
  verificeres eller nav.js-mekanikken udvides).
- `src/moduler/unitbooking/Kalender.jsx` (route `/unitbooking`) og
  `src/moduler/unitbooking/Udlaan.jsx` (route `/unitbooking/udlaan`) —
  flyt "Søg ledige"/"Reservér"/"Næste handling" fra Udlaan.jsx ind i
  Kalender.jsx som panel; `/unitbooking/udlaan` bevares som deep link
  (samme `skiftUdlaan`/`opretUdlaan`-funktioner genbruges uændret, begge
  allerede BUILT).
- `src/moduler/warehouse/Varer.jsx` (i dag route `/warehouse`, modulets
  forside) — en NY forsidekomponent oprettes (fx
  `src/moduler/warehouse/Oversigt.jsx`, route `/warehouse`), og Varer.jsx
  flyttes til en ny underside-route (fx `/warehouse/varer`). `src/App.jsx`
  og `src/fleet/nav.js` opdateres tilsvarende (ny `Route`, nyt
  `warehouseVarer`-sti-felt i nav.js). Bemærk: dette er den ENESTE ægte
  ROUTE-ændring (ikke kun nav) i denne skive, fordi `/warehouse` i dag
  PEGER på Varer.jsx direkte (`App.jsx` linje 508: `<Route path="warehouse"
  element={<Wmsvarer />} />`).
- `src/moduler/warehouse/Bevaegelser.jsx` (route
  `/warehouse/bevaegelser`) — bliver menuplaceret under et nyt "Mere"-
  undermenupunkt i `nav.js`s `warehouse`-gruppe, i stedet for på topniveau.
  Ingen ændring i selve komponenten eller dens Cloud Function
  (`bevaegelseskriv`, allerede BUILT).
- `src/moduler/warehouse/Transportlabels.jsx` (route `/warehouse/labels`)
  — indholdet bliver et kontekstuelt panel/dialog åbnet fra
  `src/moduler/warehouse/Carriers.jsx` (Beholdere) og
  `src/moduler/warehouse/Modtagelse.jsx`; `/warehouse/labels` bevares som
  deep link (samme mønster som Forslag/Arbejdskø i Skive 3).

### Change-type tag(s) pr. berørt element
- Reolpladser/Lokationer-merge: **VIEW_COMPOSITION** (bekræftet ingen
  `DATA_MODEL`-ændring nødvendig — allerede samme node)
- Kalender/Udlån-merge: **VIEW_COMPOSITION**
- Ny Warehouse-forside: **VIEW_COMPOSITION** + **ROUTE_REDIRECT** (Varer
  flytter route)
- Bevægelser til "Mere": **NAVIGATION_ONLY**
- Transportlabels kontekstuel: **VIEW_COMPOSITION**
- Ingen `BACKEND_REQUIRED`- eller `PERMISSION_MODEL`-arbejde i denne skive —
  den billigste af de driftsmodul-specifikke skiver, fordi det
  underliggende datalag allerede er korrekt delt.

### Migrationsbehov
Ingen. Dette er den ene skive hvor `04_DATA_OWNERSHIP.md` selv bekræfter at
det tungeste punkt (reolpladser/lokationer) allerede er én node — hele
skiven er UI-konsolidering af eksisterende, korrekte data- og skrivelag.

### Risici
- Den eneste reelle route-ændring (`/warehouse` skifter fra Varer til en ny
  Oversigt-komponent) betyder at ALLE eksisterende bogmærker/interne links
  til `/warehouse` nu rammer noget andet end i dag — kræver en
  `REDIRECTS`-post (`{ fra: "/warehouse/varer-gammel-alias", ... }` er
  ikke nødvendig, men en INTERN sti til den nye Varer-underside skal
  vælges konsekvent og alle interne henvisninger til den gamle
  `/warehouse`-som-varekartotek skal opdateres, jf. samme mønster som da
  Driftskalenderen overtog `/flaade` fra Enheder).
- `kraeverModul`-mekanikkens evne (eller mangel på samme) til at udtrykke
  "ét AF to moduler" for det fælles Lokationer-punkt er ikke bekræftet —
  hvis mekanikken kun understøtter én streng, kræver dette en lille,
  isoleret udvidelse af `nav.js`/`AppShell.jsx`s `harModul()`-kald, som bør
  scopes stramt for ikke at blive en de-facto Skive 2-opgave.
- Labels-kontekstualisering rører to indgangspunkter (Carriers og
  Modtagelse) — risiko for at glemme det ene, så labelet kun kan printes
  fra det ene sted i praksis.

### Testcases
- `test/reolplads.test.mjs`, `test/rules.carriers.test.mjs` — den delte
  reolplads-node og dens `flet:true`-skrivemønster.
- `test/rules.unitbooking.test.mjs`, `test/unitbooking.test.mjs` —
  Kalender/Udlån-flowets underliggende regler.
- `test/warehouse.test.mjs`, `test/rules.warehouse.test.mjs` — Warehouse
  generelt, kritisk efter route-flytningen af `/warehouse`.
- `test/transportlabel.test.mjs`, `test/stregkode128.test.mjs`,
  `test/qrkode.test.mjs` — labelmotoren, som ikke må ændre sig ved at blive
  kontekstuel.
- `test/volumen.test.mjs`, `test/sporbarhed.test.mjs` — øvrige
  Warehouse-skærme, for at bekræfte de ikke er utilsigtet påvirket af
  forsidens omlægning.
- `test/rutedeling.test.mjs` — den nye Warehouse-forsidekomponent SKAL have
  `export default` og være `lazy()`-importeret, ellers fejler den først når
  ruten åbnes hos en kunde.

### Definition of Done
- [ ] `/unitbooking` er én samlet arbejdsflade for kalender + udlån.
- [ ] Reolpladser og Lokationer er én skærm under Opsætning, tilgængelig for
      kunder med enten Unitbooking eller Warehouse (eller begge).
- [ ] `/warehouse` viser en ny modulforside, ikke varekartoteket direkte;
      varekartoteket er nået via et tydeligt undermenupunkt.
- [ ] Bevægelser er flyttet til et "Mere"-undermenupunkt.
- [ ] Transportlabels printes kontekstuelt fra Beholdere og Modtagelse;
      `/warehouse/labels` virker stadig som deep link.
- [ ] `npm test` grøn, ingen ændring i `firebase.rules.json` forventet.

### Rollback-plan
Ren UI-omlægning af allerede korrekt delte noder — `git revert`. Den ene
route-ændring (`/warehouse`) kræver at en eventuel ny `REDIRECTS`-post også
rulles tilbage sammen med koden, så et link sat i produktion mellem
udrulning og rollback ikke ender som en 404 — inkludér `REDIRECTS`-ændringen
i samme commit/revert-enhed som route-flytningen.

---

## Skive 6 — Workforce og chaufførapp

### Formål
Lukke de reelle, dokumenterede huller i Workforce: fraværsgodkendelse med
automatisk reservationsblokering, medarbejderredigering/-fratrædelse, og
en kanonisk skrivevej for kompetencevedligehold — samt tilføje
offline-sikkerhed til chaufførindberetning, som i dag mangler den
offline-kø statusmeldinger allerede har.

### Berørte rækker (blueprint-#)
- **#13** Ferie & fravær (`/bemanding/fravaer`) — FINISH: kontorets
  godkend/afvis-svar + automatisk reservation der blokerer disponering.
- **#14** Medarbejdere (`/opsaetning/medarbejdere`) — MOVE (allerede rigtig
  placering) + FINISH: redigering, fratrædelse, tydelig person/login-kobling.
- **#12** Kompetencer (`/bemanding/kompetencer`) — FINISH: kanonisk
  vedligeholdelsesvej for kompetencer/beviser (override kan vente).
- **#59** Indberetning (`/app/indberetning`) — FINISH: offline-sikkerhed +
  materialeforbrug, fotos/kvittering når fillagring (Skive 4) er klar.

### Præcise filer og routes
- `src/moduler/Fravaer.jsx` (route `/bemanding/fravaer`) — "Registrér
  fravær"-knappen er i dag permanent deaktiveret på kontorsiden (skrivning
  findes reelt kun via chaufførappens selvbetjenings-gren,
  `06_IMPLEMENTATION_STATUS.md` §03). Kræver TO nye, koblede stykker
  backend, begge `NOT_BUILT` i dag:
  1. Kontorets godkend/afvis-svar (skriv `ansoegning.status`, `afgjortAf`,
     `svar` på en `fravaer/{id}`-post) — ingen skærm gør dette i dag.
  2. Fravær → reservation ved godkendelse: `reservationFraFravaer()` er i
     dag "eksplicit kun en visning" (kildekodens egen kommentar, jf.
     `06_IMPLEMENTATION_STATUS.md`); skal blive en reel Cloud
     Function-skrivning til den delte `reservationer`-basenode
     (prioritet 30, jf. `10_DUPLICATION_AND_OVERLAP_REPORT.md`s
     "reservationer skrevet fra fire kilder").
- `src/moduler/Medarbejdere.jsx` (route `/opsaetning/medarbejdere`) —
  "Redigér" og "Registrér fratrædelse" er begge permanent deaktiverede
  (`06_IMPLEMENTATION_STATUS.md` §03). Oprettelse er allerede BUILT
  (`gem()` → `personale/<id>`); redigering/fratrædelse kræver enten en
  udvidelse af samme `gem()`-skrivevej (hvis noden ikke er `.write:false`)
  eller en ny Cloud Function — **IKKE PÅVIST** hvilken af de to, skal
  afklares mod `firebase.rules.json` ved skivens start.
- `src/moduler/Kompetencer.jsx` (route `/bemanding/kompetencer`) —
  "Overrul med begrundelse" er permanent deaktiveret, ingen Cloud Function
  fundet (`06_IMPLEMENTATION_STATUS.md` §03). Blueprintet nedskalerer selv
  ambitionen: "avanceret override kan vente" — V1-kravet er en KANONISK
  vedligeholdelsesVEJ for selve kompetence-/bevisdataen (dvs. mulighed for
  at opdatere en udløbsdato/tilføje et bevis), ikke override-mekanikken.
  Per Skive 0's verificerede fakta: læseadgangen er allerede korrekt
  modul-gatet — dette er rent `BACKEND_REQUIRED`+`VIEW_COMPOSITION` for en
  skrivevej, INGEN `PERMISSION_MODEL`-ændring.
- `src/moduler/app/Indberetning.jsx` (route `/app/indberetning`) — skriver
  i dag direkte til `indberetninger` via `gem()` UDEN Cloud Function og
  UDEN offline-kø (`06_IMPLEMENTATION_STATUS.md` §11: "Ingen offline-kø for
  denne skrivning — IKKE PÅVIST om data tabes ved reel netværksfejl").
  Chaufførappens Turplan (`src/moduler/app/Turplan.jsx`) har allerede en
  fungerende offline-kø (`meldingskoe.js`, jf. `test/meldingskoe.test.mjs`)
  — samme mønster/modul genbruges for Indberetning fremfor at bygge et nyt.
  Materialeforbrug/fotos afventer eksplicit fillagring (Skive 4) og bør
  IKKE startes før Skive 4 er afsluttet, eller sekvenseres som en
  efterfølgende delskive.

### Change-type tag(s) pr. berørt element
- Fraværsgodkendelse (kontorsvar): **BACKEND_REQUIRED**
- Fravær → reservation ved godkendelse: **BACKEND_REQUIRED** (rører den
  delt-ejede `reservationer`-node — se Risici)
- Medarbejderredigering/-fratrædelse: **BACKEND_REQUIRED** eller
  **VIEW_COMPOSITION** (afhænger af det uafklarede skrivevejs-spørgsmål)
- Kompetencevedligehold (skrivevej): **BACKEND_REQUIRED** +
  **VIEW_COMPOSITION** — eksplicit IKKE `PERMISSION_MODEL` (Skive 0's
  konklusion B)
- Offline-kø for Indberetning: **VIEW_COMPOSITION** (genbrug af
  eksisterende `meldingskoe.js`-mønster, ikke ny arkitektur)

### Migrationsbehov
Ingen datamigration for kompetence-/medarbejderskrivevejene. For
fravær→reservation: ingen migration af eksisterende fraværsposter
(reservationen skrives fremadrettet ved godkendelse, ikke bagudrettet —
samme princip som CLAUDE.md's "der er intet at fylde ud" for
opgave-reservationer, beslutning 68, gælder analogt: byg ikke en
bagudrettet udfyldning for allerede-godkendte fravær uden en eksplicit
beslutning om det).

### Risici
- **Den højeste datamodel-risiko i hele skiveplanen ligger her:**
  `reservationer` er den delt-ejede basenode med historisk dokumenteret
  skrøbelighed (CLAUDE.md/beslutning 92: en forkert gating udelukkede 37
  reservationer for én kunde). At tilføje en FEMTE reel skrivevej
  (fraværets, ved siden af booking/værksted/facility-sag) til en node der
  allerede har fire, øger overfladen for præcis den fejlklasse
  `10_DUPLICATION_AND_OVERLAP_REPORT.md` selv kalder "en tilbagevendende
  risikoklasse". Skal implementeres med samme `tjekDisponering()`-mønster
  (fem-tjek) som de øvrige tre kilder, ikke en femte, særskilt vej.
- Medarbejderredigering rører CLAUDE.md's eksplicitte advarsel om at
  `division`, `cpr`, `privatAdresse` er forbudte felter på `personale`-noden
  — enhver ny redigeringsformular skal respektere den samme feltbegrænsning
  som oprettelsesformularen allerede gør.
- Offline-kø for Indberetning skal ikke opfindes fra bunden — risikoen er
  at et nyt, parallelt kø-mønster bygges ved siden af `meldingskoe.js` i
  stedet for at genbruge det, hvilket ville gentage præcis den
  duplikeringsfejlklasse CLAUDE.md advarer mod flere steder ("et mønster
  der er dukket op seks gange").
- Materialeforbrug/fotos i Indberetning har en hård, ekstern afhængighed af
  Skive 4's fillagring — sekventeres forkert, bygges der mod et lag der
  ikke findes endnu.

### Testcases
- `test/fravaer.test.mjs`, `test/rules.ansoegning.test.mjs` — den
  eksisterende selvbetjenings-gren fraværsgodkendelsen skal bygges oven på.
- `test/rules.personale.test.mjs` — medarbejderredigeringens feltgrænser
  (`division`/`cpr`/`privatAdresse`-forbuddet).
- `test/flaade-bemanding.test.mjs` — den fælles kapacitetsgraf-kilde
  (`kapacitetsgrad()`/`ledig()`) der ikke må splitte sig igen (84% vs 83%-
  fælden, beslutning 71).
- `test/sensitivlaesning.test.mjs` — hvis fraværs-årsagsfeltet (allerede
  gated bag `fravaerSensitiveLaes`) berøres af den nye godkendelsesskærm.
- `test/statusmelding.test.mjs`, `test/meldingskoe.test.mjs`,
  `test/stop.test.mjs` — det eksisterende offline-kø-mønster fra Turplan,
  som Indberetning skal genbruge.
- `test/chaufforadgang.test.mjs` — chaufførens begrænsede rute-/
  permissionssæt, som Indberetning-ændringen ikke må udvide utilsigtet.
- `test/referencetjek.test.mjs` — hvis en ny reservation-fra-fravær
  indfører et nyt `...Id`-referencefelt.

### Definition of Done
- [ ] Kontoret kan godkende/afvise en fraværsansøgning fra
      `/bemanding/fravaer`.
- [ ] Et godkendt fravær skriver automatisk en reservation der blokerer
      disponering for den periode.
- [ ] Medarbejdere kan redigeres og fratrædes fra
      `/opsaetning/medarbejdere`.
- [ ] Kompetencer/beviser kan opdateres via en kanonisk skrivevej fra
      `/bemanding/kompetencer`.
- [ ] Chaufførens Indberetning har samme offline-sikkerhed som Turplan.
- [ ] `npm test` og `npm run test:rules` grønne.

### Rollback-plan
UI-delen: `git revert`. De nye Cloud Functions (fraværsgodkendelse,
medarbejderredigering, kompetencevedligehold) kan deaktiveres ved at
fjerne klientkaldene uden at slette funktionerne fra `functions/index.js`
med det samme. **Reservations-skrivningen fra fravær kræver særlig
opmærksomhed ved rollback:** hvis en fraværsreservation allerede er
skrevet til den delte `reservationer`-node før en rollback besluttes, skal
disse poster identificeres (fx via `kilde.type: "fravaer"`) og
enten bevares (hvis fraværet stadig gælder) eller eksplicit fjernes — en
ren kode-revert efterlader IKKE automatisk de allerede-skrevne
reservationer i en konsistent tilstand, i modsætning til de rene
UI-skiver ovenfor.

---

## Skive 7 — Økonomi og stamdata

### Formål
Bygge den manglende UI-indgang til booking→fakturagrundlag (som serveren
allerede understøtter), give kundestamdata en reel CRUD, gøre
virksomhedsoplysninger redigerbare, og placere priser/afregning korrekt
ift. de nye modulgrænser.

### Berørte rækker (blueprint-#)
- **#4** Fakturering (`/oekonomi/fakturering`) — FINISH: kanonisk
  oprettelse fra afsluttet booking/tur, konsekvent navn "Fakturagrundlag".
- **#46** Kunder (`/opsaetning/kunder`) — FINISH: opret/redigér, gør
  kundeprofilen til hjem for kontakt/aftaler/priser.
- **#49** Generelt (`/opsaetning`) — FINISH: reelt admin-center
  (virksomhedsnavn, adresse, CVR/org.nr., logo, standardlokation,
  fakturaoplysninger).
- **#42** Afregning (`/warehouse/afregning`) — MOVE til Økonomi >
  Fakturagrundlag > Warehouse.
- **#43** Volumen (`/warehouse/volumen`) — MOVE til Kunder & Priser >
  Lagerkalkulator.
- **#47** Standardpriser (`/opsaetning/priser`) — MOVE (allerede korrekt
  placeret som adminfunktion, verificér kun).
- **#48** Kundepriser (`/opsaetning/aftalepriser`) — MERGE ind i
  kundeprofilens Priser-fane.

### Præcise filer og routes
- `src/moduler/Fakturering.jsx` (route `/oekonomi/fakturering`) — **dette
  er billigere end det ser ud:** `06_IMPLEMENTATION_STATUS.md` §01
  bekræfter at "Server understøtter (`opretGrundlag()`/`grundlagskriv`
  handling 'opret'), men ingen UI-knap for en booking-tur". Kun Warehouse
  Afregning (`src/moduler/warehouse/Afregning.jsx`) kalder i dag
  funktionen, altid med en periode, aldrig et `bookingId`. Arbejdet er at
  tilføje en "Opret fakturagrundlag"-knap til Fakturering.jsx (eller til
  Bookingoversigten/en afsluttet bookings detaljevisning) der kalder samme,
  allerede-BUILT `grundlagskriv`-handling med et `bookingId`. **Ingen ny
  Cloud Function nødvendig.**
- `src/moduler/Kunder.jsx` (route `/opsaetning/kunder`) — i dag ren
  lister-og-rapportér-skærm, "ingen redigering af kundestamdata fundet
  overhovedet" (`06_IMPLEMENTATION_STATUS.md` §09). Skrivevejen for
  `kunder`-noden er **IKKE PÅVIST** i det læste materiale ud over at
  `kunder/<id>/priser/<ydelseId>/...` allerede skrives fra
  `src/moduler/kunder/Kundepriser.jsx` (`gem()`, to-permission-gate). Om
  selve kundens grundfelter (navn, kontakt, CVR) kan skrives med samme
  `gem()`-mønster eller kræver en ny funktion, skal afklares mod
  `firebase.rules.json` ved skivens start — kundeprofilen skal desuden
  blive "hjem for kontakt, aftaler og priser", dvs. en ny detaljevisning
  (fx `/opsaetning/kunder/:kundeId`) der samler dagens spredte
  Standardpriser/Kundepriser-visninger for én kunde.
- `src/moduler/opsaetning/Generelt.jsx` (route `/opsaetning`) — bevidst
  bygget som ren læseskærm i dag ("Redigér virksomhedsoplysninger" er
  deaktiveret, "Ikke besluttet endnu",
  `06_IMPLEMENTATION_STATUS.md` §09). Kræver en ny Cloud Function eller
  udvidet skrivevej for `tenants/<id>/virksomhed`-noden (navn, adresse,
  CVR/org.nr., logo, standardlokation, fakturaoplysninger) — **IKKE PÅVIST**
  hvilken mekanisme, men noden læses i dag allerede af App.jsx (linje 308)
  og bruges direkte i UI (låseskærm, sidebar-tenant-navn), så en
  klientskrivning kræver særlig omhu for ikke at bryde disse
  afhængigheder (fx `update()`-fælden CLAUDE.md advarer imod: "Skrive en
  node som ÉN nøgle i en rod-opdatering" — skriv felt for felt, ikke hele
  `virksomhed`-noden på én gang).
- `src/moduler/warehouse/Afregning.jsx` (route `/warehouse/afregning`) —
  menuplaceres om til Økonomi > Fakturagrundlag > Warehouse (samme
  komponent, ny nav-sti); ingen ændring i selve `opretGrundlag()`-kaldet.
- `src/moduler/warehouse/Volumen.jsx` (route `/warehouse/volumen`) —
  menuplaceres om til Kunder & Priser > Lagerkalkulator; ren
  beregningsskærm, ingen datamodel-ændring. Bevidst stadig INGEN
  tilbudsoprettelse (blueprintet: "Et gemt tilbud er senere").
- `src/moduler/kunder/Kundepriser.jsx` (route
  `/opsaetning/aftalepriser(/:kundeId)`) — indholdet flyttes ind som en
  fane på den nye kundeprofil-detaljevisning (se Kunder.jsx ovenfor); den
  gamle route bevares som deep link (`REDIRECTS`-mønster, allerede delvist
  til stede — `/kunder/aftalepriser/:kundeId` → `/opsaetning/aftalepriser/
  :kundeId` findes allerede i `REDIRECTS`).

### Change-type tag(s) pr. berørt element
- Booking→fakturagrundlag UI-knap: **VIEW_COMPOSITION** (bekræftet INGEN
  `BACKEND_REQUIRED` — serveren understøtter det allerede)
- Kundestamdata-CRUD: **BACKEND_REQUIRED** (skrivevej uafklaret) +
  **VIEW_COMPOSITION** (ny kundeprofil-detaljevisning)
- Virksomhedsoplysninger-editing: **BACKEND_REQUIRED**
- Afregning/Volumen/Standardpriser-flytning: **NAVIGATION_ONLY**
- Kundepriser ind i kundeprofil: **VIEW_COMPOSITION**, gammel route som
  **ROUTE_REDIRECT** (delvist allerede på plads)

### Migrationsbehov
Ingen migration for booking→grundlag (samme funktion, ny kaldsflade). For
kundestamdata og virksomhedsoplysninger: ingen migration af eksisterende
data, men en ny skrivevej skal bygges og dens regler evt. tilføjes/
udvides i `firebase.rules.json` — kræver `npm run test:rules` før commit,
jf. CLAUDE.md's ufravigelige krav.

### Risici
- Kundestamdata (`kunder`-noden) er en af de mest refererede noder i hele
  systemet — `kundeId` optræder som påkrævet felt i `bookinger`, `varer`,
  `enheder`, `plukordrer` m.fl. (jf. CLAUDE.md's `MODUL_KRAEVER`-udledning:
  "booking → kunder" og "warehouse → kunder", fordi disse noder har et
  påkrævet `kundeId`). En ny CRUD-skrivevej for kunder skal derfor
  respektere `test/referencetjek.test.mjs`s eksistenstjek-krav og må ALDRIG
  tillade en kunde at blive slettet eller ugyldiggjort mens den er
  refereret — kun statusskift (samme mønster som CLAUDE.md forbyder
  hardsletning generelt: "En post tages ud af drift med en status og en
  årsag").
- Virksomhedsoplysninger-noden (`tenants/<id>/virksomhed`) er allerede
  læst flere steder i kritisk UI (låseskærm, sidebar) — en ny skrivevej
  der ved et uheld overskriver hele noden (`update()`-på-rod-fælden) ville
  potentielt fjerne data disse afhængige visninger stoler på.
- At antage booking→grundlag kræver ny backend, når den faktisk ikke gør,
  er en modsat risiko værd at italesætte eksplicit: uden denne
  verificerede viden (fra `06_IMPLEMENTATION_STATUS.md`) kunne skiven let
  overbudgetteres.

### Testcases
- `test/grundlag.test.mjs`, `test/grundlagseksport.test.mjs`,
  `test/bookingopret.test.mjs`, `test/booking.test.mjs` — den eksisterende,
  allerede-BUILT `grundlagskriv`-handling booking-knappen skal kalde.
- `test/rules.kundepriser.test.mjs`, `test/priser.test.mjs`,
  `test/pricing-forloeb.test.mjs` — prislaget, som kundeprofilens nye
  Priser-fane skal genbruge uændret.
- `test/referencetjek.test.mjs` — kundeId-referencer på tværs af noderne
  nævnt i Risici, kritisk for at en kunde-CRUD ikke introducerer et hængende
  referencescenarie.
- `test/kpi-efterslaeb.test.mjs`, `test/kpiadgang.test.mjs`,
  `test/afkortede-totaler.test.mjs`, `test/oekonomi-graf.test.mjs`,
  `test/tom-kpi.test.mjs` — KPI-laget der læser fra `kunder`, hvis noden
  ændres.
- `test/rules.grundlag.test.mjs`, `test/rules.kpi.test.mjs`,
  `test/kpi-aggregering.test.mjs` — hvis en ny CRUD-funktion for
  virksomhedsoplysninger rører reglerne omkring den læste
  `tenants/<id>/virksomhed`-node.

### Definition of Done
- [ ] En disponent kan oprette et fakturagrundlag direkte fra en afsluttet
      booking/tur.
- [ ] "Fakturagrundlag" bruges konsekvent som navn (ikke "Fakturering") på
      tværs af UI.
- [ ] Kundeprofilen er hjem for kontakt, aftaler og priser; kunder kan
      oprettes og redigeres.
- [ ] Opsætning > Virksomhed kan redigere navn, adresse, CVR/org.nr., logo,
      standardlokation, fakturaoplysninger.
- [ ] Afregning og Volumen er flyttet til deres nye menuplaceringer;
      gamle routes virker som deep links.
- [ ] Kundepriser er en fane på kundeprofilen; gammel route redirecter.
- [ ] `npm test` og `npm run test:rules` grønne.

### Rollback-plan
UI/nav-delen: `git revert`. Booking→grundlag-knappen: fjern knappen,
allerede-oprettede grundlag forbliver gyldige (samme datamodel som
Warehouse-oprettede grundlag, ingen særbehandling). Kundestamdata- og
virksomheds-CRUD: samme forsigtighed som Skive 6 — hvis nye skrivninger er
foretaget via de nye funktioner før en rollback, skal disse ændringer
vurderes individuelt (er den nye kundeadresse fx allerede brugt på en
udstedt faktura?) frem for en automatisk tilbagerulning af data.

---

## Skive 8 — Visuel konsolidering og release

### Formål
Anvende de fem sidetyper konsekvent, harmonisere spacing/toolbar/
sidepaneler på tværs af alle skærme, validere samtlige 7 roller ×
modulkombinationer i DEV, dokumentere de kanoniske arbejdsgange, og
opnå en grøn fuld testsuite som release-gate.

### Berørte rækker (blueprint-#)
Ingen enkeltstående blueprint-rækker — dette er den tværgående
afslutningsskive der dækker blueprintets "Definition of Done for
oprydningsprogrammet" i sin helhed:
- Fem sidetyper: modul-forside, kalender, arbejdskø, proces, stamdata.
- Kun én primær blå handling pr. arbejdsområde (produktgrundlov §9).
- Alle 7 roller og relevante modulkombinationer valideret i DEV.
- Fuld testsuite grøn, dokumenteret rollback pr. skive (denne fil).

### Præcise filer og routes
- Ingen ny funktionalitet, ingen nye routes. Arbejdet er en gennemgang af
  ALLE skærme berørt af Skive 1–7 (samt de KEEP-skærme der ikke er rørt,
  for at bekræfte de allerede følger et af de fem mønstre) mod:
  - `src/fleet/fleet.css` — designtokens (CLAUDE.md: "Definere egne
    farver" og "Sætte en `font-size` i px" er begge forbudt uden for denne
    fil, håndhævet af `npm run test:design`).
  - Toolbar-/sidepanel-komponenter i `src/fleet/ui.jsx` (fælles UI-byggesten,
    jf. CLAUDE.md's "Lave en sidebar, tenant-vælger eller periodevælger i
    et modul" — forbudt, shellen ejer dem).
- `src/fleet/AppShell.jsx` — verificér modulvælger/sidebar-adfærd for hver
  af de 7 roller (jf. `docs/product-audit/05_ROLES_AND_PERMISSIONS.md`) i
  DEV-miljøet, inkl. Brugervælgeren (`fleet/Brugervaelger.jsx`) til
  sessionsskift mellem seedede DEV-brugere.
- `docs/product-redesign-v1/03_CANONICAL_WORKFLOWS.md` (produceres af en
  tidligere/parallel del af planlægningspakken, jf. blueprintets
  "Første besked"-liste) — verificeres mod den FAKTISKE tilstand efter
  Skive 1–7, ikke kun mod planen.

### Change-type tag(s) pr. berørt element
- Sidetype-/spacing-harmonisering: **VIEW_COMPOSITION**
- Rolle×modul-DEV-validering: ingen kodeændring i sig selv — et
  test-/verifikationsarbejde, tags kun de rettelser det afdækker
  (typisk **VIEW_COMPOSITION** eller **NAVIGATION_ONLY**, afhængig af fund).
- Ingen `DATA_MODEL`, `BACKEND_REQUIRED` eller `PERMISSION_MODEL`-arbejde er
  planlagt i denne skive — finder rolle×modul-valideringen et reelt
  sikkerhedshul, hører rettelsen til i en NY, separat sikkerhedsskive, ikke
  i visuel konsolidering (jf. CLAUDE.md's låste rækkefølge for
  sikkerhedsarbejde).

### Migrationsbehov
Ingen.

### Risici
- Denne skive er den eneste der rører design-tokens/typografi på tværs af
  ALLE skærme — risiko for at røre en af de tre eksplicit dokumenterede
  undtagelser (CLAUDE.md: labels 100×200mm, donut-graf i viewBox-enheder)
  uden at bevare deres begrundelse i `test/skrift.test.mjs`.
- Rolle×modul-validering i DEV kan afdække reelle huller Skive 1–7 ikke
  fangede (fx en nav-gruppe der stadig peger forkert efter en flytning,
  jf. Skive 1's `sti`-repoint-risiko) — denne skive skal derfor have et
  rimeligt tidsbudget til RETTELSER, ikke kun verifikation, uden at blive
  en de-facto niende skive.
- At denne skive er sidst betyder den arver enhver uadresseret risiko fra
  Skive 1–7 — den bør ikke startes før mindst Skive 1–3 (de mest
  navigationstunge) er afsluttet og deres egne DoD-lister er krydset af.

### Testcases
- `test/design-tokens.test.mjs`, `test/kontrast.test.mjs`,
  `test/skrift.test.mjs`, `test/css-navne.test.mjs` — hele
  designtoken-/farve-/typografi-disciplinen.
- `test/navadgang.test.mjs`, `test/rules.rollematrix.test.mjs` — endelig,
  tværgående bekræftelse af nav/permission-sammenhæng for alle 7 roller.
- **Fuld suite:** `npm test` (inkl. alle ovenstående skivers testfiler) og
  `npm run test:rules` som release-gate, jf. blueprintets DoD ("Fuld
  test-suite er grøn").
- DEV-accepttest (manuel, ikke i `test/`): log ind som hver af de 7 seedede
  DEV-roller via `Brugervaelger.jsx` og gennemgå de kanoniske arbejdsgange
  fra `03_CANONICAL_WORKFLOWS.md` end-to-end.

### Definition of Done
- [ ] Hver skærm er klassificeret som én af de fem sidetyper, og afviger
      ikke fra dens mønster uden en skreven begrundelse.
- [ ] Ingen arbejdsområde har mere end én primær blå handling.
- [ ] Alle 7 roller er gennemgået i DEV mod relevante modulkombinationer;
      fund er enten rettet eller eksplicit accepteret og noteret.
- [ ] `03_CANONICAL_WORKFLOWS.md` afspejler den faktiske, byggede tilstand.
- [ ] `npm test` og `npm run test:rules` er begge grønne som release-gate.
- [ ] Denne fils rollback-planer for Skive 1–7 er verificeret læsbare og
      brugbare (ikke kun skrevet, men afprøvet i det omfang det er
      risikofrit at gøre — fx en `git revert --no-commit` dry-run).

### Rollback-plan
Design-/spacing-ændringer: `git revert`, ingen datapåvirkning. Denne skive
introducerer ingen ny funktionalitet i sig selv og har derfor ingen egen
datamæssig rollback-risiko — dens rollback-ansvar er at have VERIFICERET at
Skive 1–7's individuelle rollback-planer holder, ikke at tilføje en ny.
Hvis release-gaten (fuld suite) ikke er grøn, er "rollback" for denne skive
reelt: udskyd release, fasthold koden på seneste grønne skive, og fortsæt
rettelser uden at skive-grænsen mellem 7 og 8 brydes.
