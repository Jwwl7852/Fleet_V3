<title>Data- og permissionpåvirkning</title>

# 04 — Data- og permissionpåvirkning

⚠ **Denne runde er kun planlægning. 0 ændringer i produktkode,
`firebase.rules.json`, Cloud Functions eller data er foretaget for at
producere dette dokument.** Kilder: `FleetControl_V1_product_blueprint.md`,
`00_AUTHORITATIVE_PRODUCT_RULES.md`, `docs/product-audit/04_DATA_OWNERSHIP.md`,
`docs/product-audit/05_ROLES_AND_PERMISSIONS.md`,
`docs/product-audit/10_DUPLICATION_AND_OVERLAP_REPORT.md`, samt direkte
læsning af `src/fleet/moduler.js`, `src/fleet/nav.js`,
`src/fleet/permissions.js` og de relevante uddrag af `firebase.rules.json`.

## Metodenote

For hver blueprint-beslutning der plausibelt rører data eller adgang,
identificerer dette dokument PRÆCIS hvad der skal ændres — og lige så
vigtigt, hvad der IKKE skal:

- **RTDB-nodestruktur / `NODE_MODUL`** (`src/fleet/moduler.js`) — hvilket
  modul en node er spærret til.
- **`firebase.rules.json`** — den udrullede håndhævelse af samme spærring,
  plus eventuelle permission-krav på selve `.read`/`.write`.
- **`permissions.js`/`ROLLE_PERMS`** — hvilke permissions en rolle har som
  standard.
- **Ren UI-omlægning** — `src/fleet/nav.js` (menuplacering, `kraeverModul`,
  `kraeverPerm`) og selve skærmkomponenterne, uden at røre nogen af de tre
  ovenstående.

De fire første kategorier er sikkerhedsrelevante og kræver
`npm run test:rules` (obligatorisk, jf. `CLAUDE.md`) plus
`npm run regler:udrul` — de er ikke "bare en tekstændring i en JSON-fil".
Den sidste kategori er en frontend-omlægning uden sikkerhedskonsekvens.

**Hovedkonklusionen, fastslået allerede her:** langt de fleste MERGE/MOVE-
beslutninger i blueprintet er rene UI-omlægninger, fordi de underliggende
delte noder allerede findes (jf. `04_DATA_OWNERSHIP.md`s dokumentation af
`reolpladser` som eneste to-modul-node, og af `fakturaer`, `satser`,
`opgaver`, `reservationer`, `sager` som bevidst placeret i basen). Det
de-risker en stor del af oprydningsplanen: den ændrer navigation og
sidekomposition, ikke databasens sikkerhedsmodel, i de fleste tilfælde.

---

## Ingen datamodel-ændring nødvendig (ren UI-omlægning)

| # | Beslutning | Hvorfor det er UI-only | Change-type |
|---:|---|---|---|
| 7 | Forslag & reservation → panel i Disponering | Begge skærme viser allerede samme etaper og kalder samme `tjekDisponering()` (`10_DUPLICATION…md`, "Booking → Forslag … / Disponering", risiko "Ingen — dokumenteret som bevidst delt"). Forslaget ligger på etapen (`etaper/<id>/forslag/<id>`), ikke i en selvstændig node. At vise det i et panel frem for en selvstændig route ændrer intet i noden. Ruten bevares som deep link. | VIEW_COMPOSITION + ROUTE_REDIRECT (for den gamle selvstændige route) |
| 10 | Bookingopsætning → Opsætning > Planning | Læser/skriver `satser`/`omkostninger`, begge allerede base/booking-ejede noder med uændret gating (`kraeverPerm: "satser.laes"` i `nav.js` i dag). Kun menuplaceringen flytter. | NAVIGATION_ONLY |
| 14 | Medarbejdere → Opsætning | Allerede placeret der i dag (`nav.js`: `/opsaetning/medarbejdere`). `personale` er en bevidst BASE-node ("enhver abonnementskombination har medarbejdere", `moduler.js` linje 296-298 og `04_DATA_OWNERSHIP.md`). Ingen flytning at foretage — kun verifikation af at placeringen allerede er rigtig, plus CRUD-finish (BACKEND_REQUIRED/VIEW_COMPOSITION, ikke PERMISSION_MODEL). | NAVIGATION_ONLY (allerede opfyldt) |
| 26 | Godkendelser: policy-opsætning → Opsætning > Procure | `godkendelsesregler` er én post pr. tenant, ejet af `indkoeb`, læst identisk af både Godkendelser- og Fakturaer-skærmen (`10_DUPLICATION…md`: "Ingen reel divergens fundet — begge læser korrekt samme kilde"). Kun UI'et der VISER/REDIGERER reglen flytter til Opsætning; den operationelle kø bliver i Procure og læser stadig samme post. Ingen ny permission — `indkoeb.godkend`/`indkoeb.laes` er uændrede. | VIEW_COMPOSITION |
| 27 | Procure-fakturaer → Fakturaer & bilag (filter=Procure) | Samme `fakturaer`-node, som allerede er `.read`-tilgængelig for enhver tenant-bruger uden modulklausul og uden permission-krav (verificeret direkte i `firebase.rules.json`, linje 2916-2924: kun `auth != null` + tenant-match + aktivt abonnement). De to skærme deler allerede `matchForslag()`/`foreslaaDestination()` (`10_DUPLICATION…md`). Route kan rendes redirecte. | ROUTE_REDIRECT |
| 31 | Udlån → Kalender & udlån | `kasseudlaan` er uændret ejet af `unitbooking`, skrevet udelukkende via `kasseudlaanskriv`. Kun søg-ledig/reservér-panelet flytter ind i kalenderskærmen; samme Cloud Function, samme node. | VIEW_COMPOSITION |
| 33 | Reolpladser → Opsætning > Lagerlokationer (merge med Warehouse Lokationer) | `reolpladser` er allerede eksplicit `NODE_MODUL.reolpladser = ["unitbooking", "warehouse"]` — den ENESTE node i kodebasen med formelt to-modul-ejerskab, skrevet med `flet: true` netop for at de to moduler ikke skal overskrive hinandens felter (`moduler.js` linje 373-382, `04_DATA_OWNERSHIP.md`, `10_DUPLICATION…md`: "et rent, gennemtænkt shared-node-design"). At vise ét vindue i stedet for to ændrer INTET i node eller regler — kun hvilken(e) skærm(e) der renderer den samme kilde. | VIEW_COMPOSITION |
| 41 | Transportlabels → kontekstuel fra Beholdere/Modtagelse | Labelmotoren har ingen egen node — "typen udledes af etapekæden, felterne slås op, intet gemmes" (`nav.js` kommentar ved `warehouseLabels`). At gøre den kontekstuel ændrer ikke noget datalag, kun hvorfra den åbnes. Route bevares som deep link. | VIEW_COMPOSITION + ROUTE_REDIRECT |
| 45 | Lokationer → Opsætning > Lagerlokationer (merge med Unitbooking Reolpladser) | Identisk sag som #33, set fra Warehouse-siden — samme delte `reolpladser`-node. De to blueprint-rækker peger på ÉT sammenlagt vindue over ÉN node, ikke to migreringer. | VIEW_COMPOSITION |
| 48 | Kundepriser → Kundeprofil > Priser-fane | Kundeafvigelsen ligger allerede fysisk på kunden (`kunder/<id>/priser/...`), logget i audit som `objekt: "satser"` (`04_DATA_OWNERSHIP.md`). `kraeverModul: "kunder"` og `kraeverPerm: "satser.laes"` er uændrede i dag (`nav.js` linje 352-357) — kun visningen flytter fra selvstændig topskærm til en fane på kundeprofilen. Deep link bevares. | VIEW_COMPOSITION |

---

## Reel datamodel-påvirkning

### #28 — Leverandører → fælles stamdata (Fleet, Facility, Procure)

Dette er den **eneste** blueprint-beslutning i det undersøgte sæt der kræver
en reel `NODE_MODUL`/`firebase.rules.json`-ændring.

**I dag:** `NODE_MODUL.leverandoerer = "indkoeb"` (`moduler.js` linje 321,
med eksplicit begrundelse: "modsat `fakturaer`, som står i basen fordi to
skærme rører den — en leverandør røres kun af Indkøb"). Den deployede regel
(`firebase.rules.json` linje ~2440) håndhæver **både** modulklausulen
(kræver `moduler/indkoeb === true`) **og** `.read: indkoeb.laes`. Samtidig
dokumenterer både reglens egen kommentar og `04_DATA_OWNERSHIP.md`
eksplicit at noden allerede **læses af elleve skærme, også uden for
Procure**: Disponering, Servicekalender, Arbejdskøen og Værkstedskalender
slår alle op i kartoteket for at vise et leverandørnavn.

**Konsekvens i dag:** en tenant med Fleet og/eller Facility, men UDEN
Procure, får en afvist læsning på `leverandoerer` fra de fire skærme
ovenfor. `useListe`s `modulerForNode()`-mekanisme (beslutning 94) gør det
til en stille `modulMangler`-tilstand snarere end en fejl, men resultatet
er at disse kunder reelt ikke kan se leverandørnavne i deres egne
arbejdsskærme — præcis den tilstand blueprintets "fælles stamdata for
Fleet, Facility og Procure" skal rette.

**Hvad der PRÆCIST skal ændres:**

1. **`src/fleet/moduler.js` (`NODE_MODUL`):** flyt `leverandoerer` ud af
   `indkoeb`-linjen og ind i basen — en **sjette** navngiven undtagelse ved
   siden af `opgaver`, `satser`, `fakturaer`, `reservationer`, `sager`,
   efter nøjagtig samme begrundelsesmønster ("en node der hører til flere
   modulers arbejdsgange, kan ikke gates af det ene uden at de andre går i
   stykker").
2. **`firebase.rules.json`:** fjern modulklausulen på `leverandoerer`s
   `.read`/`.write`. `npm run test:rules` er obligatorisk efter ændringen
   (jf. `CLAUDE.md`), fordi `test/rules.moduler.test.mjs` udleder de
   håndhævede regler direkte af `NODE_MODUL`-objektet og vil fejle indtil
   de to filer stemmer overens.
3. **`permissions.js`/`ROLLE_PERMS`: sandsynligvis INGEN ændring.**
   `indkoeb.laes` er allerede en del af standardsættet for `casehandler`,
   `disponent`, `koordinator`, `lagermedarbejder` og `revisor` (alle roller
   der reelt bruger Disponering/Servicekalender/Arbejdskøen/
   Værkstedskalender) — kun `chauffoer` mangler den, og chaufføren bruger
   ingen af de fire skærme (`05_ROLES_AND_PERMISSIONS.md`). Den reelle
   spærre er modulklausulen, ikke permission-fordelingen. Behold
   `.read: indkoeb.laes` på den flyttede node, medmindre en fremtidig
   gennemgang beslutter at kravet selv skal lempes (det er ikke en del af
   denne beslutning).

**Risiko ved migrering:** lav på dataniveau (ingen felter ændres, ingen
poster flyttes — kun en gate der løsnes), men sikkerhedsrelevant nok til at
kræve fuld regelkørsel og en bevidst udrulning, ikke en stille redeploy.
Den reelle risiko er ikke tab af data, men at CRUD på leverandører (som
`nav.js`'s egen kommentar ved leverandørnoden bemærker har "været planlagt,
ikke glemt") først skal bygges færdig, før Fleet/Facility-brugere kan
RETTE en leverandør de nu kan SE — ellers ser de en post de ikke kan
vedligeholde, hvilket er en ufærdig-flade-risiko af samme klasse som
blueprintets regel 10 advarer imod.

### #3 — Fakturacenter som fælles platformfunktion, uafhængig af Procure-abonnement

Vurderet grundigt, fordi opgaven bad om præcision: **dette kræver INGEN
`NODE_MODUL`- eller `firebase.rules.json`-ændring.** `fakturaer` er allerede
en af de fem bevidst ugatede base-noder (`moduler.js` linje 263-277,
`04_DATA_OWNERSHIP.md`) — den deployerede regel (`firebase.rules.json`
linje 2916-2924) kræver kun `auth != null`, tenant-match og aktivt
abonnement, INTET permission-krav og INGEN modulklausul.

Det der reelt spærrer i dag, sidder udelukkende i `src/fleet/nav.js`:

- Menupunktet `fakturacenter` (linje 261) bærer `kraeverPerm:
  "indkoeb.laes"` — en UI-gate der er strengere end den underliggende
  regel, og som binder skærmen til Procure-permissionen selvom Procure
  ikke ejer dataen.
- Punktet ligger som barn af den `oekonomi`-topmenu (linje 239), hvis
  synlighed selv afhænger af at tenanten har det VALGFRIE `oekonomi`-modul
  — så en kunde uden Procure OG uden Økonomi-modulet kan i dag slet ikke
  nå Fakturacenter fra menuen, på trods af at data er fuldt tilgængelig.

**Hvad der PRÆCIST skal ændres — kun `src/fleet/nav.js`:**

1. Løft `fakturacenter` ud af `oekonomi`-gruppen til sit eget altid-synlige
   topmenupunkt, i tråd med målbilledets "Fælles: Dashboard · Kunder ·
   Fakturaer & bilag · Økonomi / Fakturagrundlag" (`00_AUTHORITATIVE…md`).
2. Fjern `kraeverPerm: "indkoeb.laes"` (eller — hvis et bevidst
   permission-krav ønskes — erstat det med noget der IKKE er
   Procure-specifikt; blueprintet beder om uafhængighed af Procure, så det
   enkleste og mest tro valg er intet permission-krav, i tråd med den
   deployerede regel).

Dette er **NAVIGATION_ONLY**. Effekten på hvem der reelt kan se skærmen er
i praksis lille: alle roller undtagen `chauffoer` har allerede
`indkoeb.laes` som standard (`05_ROLES_AND_PERMISSIONS.md`), og chaufføren
har siden beslutning 117 slet ikke adgang til AppShell/sidebaren. Ændringen
handler om at gøre en allerede-tilgængelig, allerede-ugatet node
FINDIBAR uafhængigt af hvilke moduler tenanten har, ikke om at åbne en ny
sikkerhedsdør.

---

## Permission-model påvirkning

### #26 — Godkendelser-policy til Opsætning > Procure

Ingen permission-ændring. Både den operationelle kø (der bliver i Procure)
og opsætningsskærmen (der flytter) læser samme `godkendelsesregler`-post
via samme `usePost(null, "godkendelsesregler")`-kald (`10_DUPLICATION…md`).
`indkoeb.laes` (læs) og hvad end der i dag kræves for at redigere reglen
(ikke fundet som en separat named permission i det læste
`permissions.js`-udtræk — antages dækket af `indkoeb.godkend`/generel
skriveadgang; **IKKE PÅVIST** i detalje i denne runde, bør bekræftes i
Skive 4 før implementering) er uændret af en ren menuflytning.

### #46 — Kunder flyttes ud af Opsætning

Direkte besvarelse af opgavens spørgsmål: **kræver ingen
permission-ændring.** `kunder.laes` (`PERM.kunderLaes`) indgår i
`BASIS_LAES`, som ALLE syv roller får som en del af deres standardsæt —
inklusive `chauffoer` (`permissions.js` linje 359-363, bekræftet for hver
af de syv rolle-presets i linje 377-553). Der findes altså ingen rolle i
dag der IKKE allerede kan læse kundedata; kun `kraeverModul: "kunder"`
(kommerciel spærre — har tenanten overhovedet købt kunde-modulet) afgør om
menupunktet vises, og den er uændret af at flytte det fra Opsætning-grenen
til et nyt topmenupunkt.

**Den ene reelle nuance:** i dag ligger "Kunder" som `kunderOversigt` inde
under Opsætning (`nav.js` linje 338-340), hvor det kun ses af brugere der i
forvejen navigerer ind i en administrativ menu. At gøre det til et
ligeværdigt topmenupunkt ("Kunder — kun når relevant") ØGER dets synlighed
og opdagelighed for alle roller, men ikke deres FAKTISKE adgang — den var
allerede universel via `BASIS_LAES`. Dette er præcis den type ændring
`CLAUDE.md` advarer om at holde adskilt: "navigationssynlighed … er en
ANDEN mekanisme end permissions" — synligheden ændres bevidst, sikkerheden
er allerede der og upåvirket.

### #3 (Fakturacenter) og #28 (Leverandører)

Se de to punkter under "Reel datamodel-påvirkning" ovenfor — begge har en
permission-dimension der er behandlet der for at undgå at sagen splittes
over to sektioner.

---

## Migrationsbehov

Efter gennemgang af alle 16 vurderede beslutninger er der **kun ét reelt
migrationsbehov af substans**: #28 Leverandører (se ovenfor). Det er
ikke en datamigrering i klassisk forstand — ingen felter omdøbes, ingen
poster flyttes, intet slettes. Det er en **gate-lempelse**:
`leverandoerer` flytter fra ét modul-ejerskab til basen, på præcis samme
måde som `reservationer` gjorde det i beslutning 92 (dokumenteret i
`moduler.js` og `04_DATA_OWNERSHIP.md`s "Steder hvor et modul fejlagtigt
ejer data"-afsnit) — det historiske forbillede for netop denne klasse
rettelse i denne kodebase.

Dette er i tråd med kodebasens etablerede disciplin (`CLAUDE.md`):

- **Additiv, ikke destruktiv.** Ingen felter fjernes eller omdøbes på
  `leverandoerer`-posterne. Eksisterende data er allerede i den rigtige
  form; kun læse-/skriveretten ændres.
- **Ingen hard-delete, nogensinde** — ikke relevant her, da intet slettes,
  men nævnt for fuldstændighed: ville en fremtidig oprydning ønske at
  fjerne `indkoeb`-ejerskabet helt fra kommentarer/dokumentation, skal selve
  dataen stadig stå urørt.
- **Regelændring kræver `npm run test:rules` FØR commit, ingen undtagelser**
  — også selvom ændringen "kun" fjerner en modulklausul. `CLAUDE.md` er
  eksplicit om at netop den slags — en tilsyneladende lille
  regelændring — historisk har været den fejltype der overlevede måneder
  udeteceret, fordi ingen kørte suiten.
- **Udrulning er et separat trin fra filændringen** — `npm run
  regler:udrul`, ikke `firebase deploy` alene, jf. beslutning 29.

**Ingen andre af de 16 vurderede beslutninger kræver et migrationsskridt.**
Det skal siges ærligt, fordi opgaven bad om det: langt størstedelen af
blueprintets MOVE/MERGE-rækker er navigations- og komponent-omlægninger
oven på data der allerede er korrekt formet og korrekt delt.

---

## Sammenfatning: hvilke MOVE/MERGE-beslutninger er "gratis" vs. "koster"

| Blueprint-# | Beslutning | Kræver DATA_MODEL/PERMISSION_MODEL-ændring? | Hvis ja, hvad |
|---:|---|---|---|
| 3 | Fakturacenter → fælles platformfunktion, uafhængig af Procure | **Nej** | `fakturaer` er allerede ugated base-node. Kun `nav.js`: løft ud af `oekonomi`-gruppen til eget topmenupunkt, fjern `kraeverPerm: "indkoeb.laes"`. |
| 7 | Forslag & reservation → panel i Disponering | Nej | Samme `etaper/forslag`-node, samme `tjekDisponering()`. Ren VIEW_COMPOSITION. |
| 10 | Bookingopsætning → Opsætning > Planning | Nej | Samme `satser`/`omkostninger`, uændret `kraeverPerm`. Ren menuflytning. |
| 14 | Medarbejdere → Opsætning | Nej | Allerede korrekt placeret; `personale` er allerede base. Kun verifikation. |
| 26 | Godkendelser-policy → Opsætning > Procure | Nej | Samme `godkendelsesregler`-post, samme permissions; kun UI splittes i kø (Procure) + opsætning (Opsætning). |
| 27 | Procure-fakturaer → Fakturaer & bilag (redirect) | Nej | Samme ugated `fakturaer`-node. Ren ROUTE_REDIRECT. |
| 28 | Leverandører → fælles stamdata (Fleet/Facility/Procure) | **Ja** | Flyt `leverandoerer` fra `NODE_MODUL.indkoeb` til basen (6. navngivne undtagelse); fjern modulklausul i `firebase.rules.json`; behold `indkoeb.laes`-kravet (allerede bredt tildelt). Kræver `npm run test:rules` + `regler:udrul`. |
| 31 | Udlån → Kalender & udlån | Nej | Samme `kasseudlaan`-node/funktion. Ren VIEW_COMPOSITION. |
| 33 | Reolpladser → Opsætning > Lagerlokationer | Nej | `reolpladser` er allerede formelt to-modul-ejet (`["unitbooking","warehouse"]`), `flet: true`. Ren VIEW_COMPOSITION. |
| 41 | Transportlabels → kontekstuel | Nej | Ingen egen node i dag. Ren VIEW_COMPOSITION/ROUTE_REDIRECT. |
| 42 | Afregning → Økonomi > Fakturagrundlag > Warehouse | Nej* | Samme `bevaegelser`/`grundlag`. *Kræver at det eksplicitte `kraeverModul: "warehouse"` bevares på selve menupunktet, da det mister den implicitte arv fra Warehouse-gruppen ved at blive reparentet. |
| 43 | Volumen → Kunder & Priser > Lagerkalkulator | Nej* | Samme `satser`-opslag. *Samme forbehold som #42 — eksplicit `kraeverModul: "warehouse"` skal tilføjes ved reparentering. |
| 45 | Lokationer → Opsætning > Lagerlokationer (merge m. Reolpladser) | Nej | Identisk sag som #33 — samme node, set fra den anden skærm. |
| 46 | Kunder → ud af Opsætning | Nej | `kunder.laes` er allerede i `BASIS_LAES` for alle 7 roller. Kun synlighed/opdagelighed ændres, ikke adgang. |
| 47 | Standardpriser → Opsætning > Priser | Nej | Allerede korrekt placeret i `nav.js` i dag (`/opsaetning/priser`). Kun verifikation. |
| 48 | Kundepriser → Kundeprofil > Priser-fane | Nej | Data ligger allerede på kunden (`kunder/<id>/priser`), uændret `kraeverModul`/`kraeverPerm`. Ren VIEW_COMPOSITION. |

**Total: 15 af 16 vurderede beslutninger er "gratis" (ingen DATA_MODEL- eller
PERMISSION_MODEL-ændring) — 1 (#28, Leverandører) kræver reelt arbejde i
`NODE_MODUL`/`firebase.rules.json`, og det arbejde er en gate-lempelse uden
feltmigrering.**
